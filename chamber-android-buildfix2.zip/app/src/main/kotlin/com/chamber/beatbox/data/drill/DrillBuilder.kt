package com.chamber.beatbox.data.drill

import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.db.entities.FileMetaEntity
import kotlin.math.max
import kotlin.random.Random

/**
 * Ports the HTML's drillBuild() + reviewQueue() + drillBpmGaps().
 *
 * Builds a timed practice session from the user's own data:
 * - Warm-up if throat is cold
 * - Spaced-repetition technique reviews
 * - Oldest unfinished champ routine
 * - Tempo gaps (BPM ranges with zero coverage)
 * - Cold genres (never used)
 * - Pattern Lab lock / write
 * - Battle round
 * - Optional free block to fill remaining minutes
 */
object DrillBuilder {

    data class DrillBlock(
        val name: String,
        val minutes: Int,
        val bpm: Int = 0,
        val click: Boolean = true,
        val route: String? = null,          // e.g. "s/trainer", "e/{id}"
        val entryId: String? = null,
        val rate: Boolean = false,          // prompt re-rate at end
        val why: String = "",
        val fixed: Boolean = false,         // warm-up is fixed
        val tab: String? = null             // trainer tab hint
    )

    data class ReviewItem(
        val technique: EntryEntity,
        val confidence: Int,                // last confidence rating 1-5 (0 = never)
        val daysSince: Double,
        val score: Double                   // lower = more due
    )

    data class DrillPlan(
        val minutes: Int,
        val seed: Int,
        val blocks: List<DrillBlock>,
        val totalMinutes: Int
    )

    // ── Public API ────────────────────────────────────────────────────────────

    fun build(
        minutes: Int,
        seed: Int = 0,
        allEntries: List<EntryEntity>,
        fileCounts: Map<String, Int>,
        lastWarmIso: String?,
        dayKey: String = java.time.LocalDate.now().toString()
    ): DrillPlan {
        val r = Random(hashStr("drill:$dayKey:$minutes:$seed").toLong())
        val blocks = mutableListOf<DrillBlock>()

        // 1. Warm-up if cold (>16 h since last full warm-up)
        val warmAgeHours = lastWarmIso?.let {
            try {
                val then = java.time.Instant.parse(it)
                java.time.Duration.between(then, java.time.Instant.now()).toHours().toDouble()
            } catch (_: Exception) { 1e6 }
        } ?: 1e6

        if (warmAgeHours > 16) {
            val why = if (lastWarmIso != null)
                "Last full warm-up was some time ago — cold throat bass is how people lose months"
            else
                "No warm-up ever logged — cold throat bass is how people lose months"
            blocks += DrillBlock(
                name = "Warm-up",
                minutes = 5,
                bpm = 70,
                click = false,
                route = "s/trainer",
                tab = "warm",
                why = why,
                fixed = true
            )
        }

        // 2. Spaced-repetition technique reviews (top 2 due)
        reviewQueue(allEntries, limit = 2).forEach { item ->
            blocks += DrillBlock(
                name = "Review — ${item.technique.name}",
                minutes = 6,
                bpm = item.technique.bpm ?: 110,
                click = true,
                route = "e/${item.technique.id}",
                entryId = item.technique.id,
                rate = true,
                why = reviewWhy(item) + ". Re-rate it at the end of the block."
            )
        }

        // 3. Oldest unfinished championship routine
        val champs = allEntries.filter { it.kind == "champ" && it.status != "Completed" && !it.deleted }
        if (champs.isNotEmpty()) {
            val target = champs.minByOrNull { it.updatedAt }!!
            blocks += DrillBlock(
                name = "Run it — ${target.name}",
                minutes = 8,
                bpm = target.bpm ?: 0,
                click = (target.bpm ?: 0) > 0,
                route = "e/${target.id}",
                entryId = target.id,
                why = "${target.status ?: "Idea"} · untouched for a while. Full pass, no stopping to fix things."
            )
        }

        // 4. Tempo gap
        val gaps = bpmGaps(allEntries)
        if (gaps.isNotEmpty()) {
            val g = gaps.random(r)
            val bpm = r.nextInt(g.low, g.high + 1)
            blocks += DrillBlock(
                name = "Tempo gap — $bpm BPM",
                minutes = 5,
                bpm = bpm,
                click = true,
                route = "s/trainer",
                why = "Nothing in your whole library sits at this tempo. Range is the first thing a judge hears."
            )
        }

        // 5. Cold genre (never used / no files / no links)
        val coldGenres = allEntries.filter { e ->
            e.kind == "genre" && !e.deleted &&
                (fileCounts[e.id] ?: 0) == 0 &&
                parseJsonList(e.links).isEmpty() &&
                parseJsonList(e.tags).isEmpty()
        }
        if (coldGenres.isNotEmpty()) {
            val cg = coldGenres.random(r)
            val gt = genreTempo(cg.name)
            blocks += DrillBlock(
                name = "Cold genre — ${cg.name}",
                minutes = 6,
                bpm = gt,
                click = true,
                route = "e/${cg.id}",
                entryId = cg.id,
                why = "In your library, never used. Eight bars is enough to find out whether it suits you."
            )
        }

        // 6. Pattern Lab
        val patterns = allEntries.filter { it.kind == "pattern" && !it.deleted }
        if (patterns.isNotEmpty()) {
            val p0 = patterns.first()
            blocks += DrillBlock(
                name = "Lock the groove — ${p0.name}",
                minutes = 4,
                bpm = p0.bpm ?: 100,
                click = false,
                route = "e/${p0.id}",
                entryId = p0.id,
                why = "Mute one lane and hold that part yourself. The machine keeps the rest honest."
            )
        } else {
            blocks += DrillBlock(
                name = "Write one pattern",
                minutes = 4,
                bpm = 100,
                click = true,
                route = "s/pattern",
                why = "Nothing in Pattern Lab yet. A groove you can only feel is one you cannot repeat on demand."
            )
        }

        // 7. Battle round
        blocks += DrillBlock(
            name = "Battle round — 90s",
            minutes = 3,
            bpm = 0,
            click = false,
            route = "s/battle",
            why = "Pressure is a different skill. One clean round."
        )

        // Trim or pad to target minutes
        var plan = fitToMinutes(blocks, minutes)

        return DrillPlan(
            minutes = minutes,
            seed = seed,
            blocks = plan,
            totalMinutes = plan.sumOf { it.minutes }
        )
    }

    // ── Spaced repetition ─────────────────────────────────────────────────────

    fun reviewQueue(allEntries: List<EntryEntity>, limit: Int = 5): List<ReviewItem> {
        val techniques = allEntries.filter {
            it.kind == "technique" && !it.deleted
        }
        return techniques.mapNotNull { t ->
            val logs = parseLog(t.log)
            val confLogs = logs.filter { it.k == "confidence" || it.k == "conf" }
            val lastConf = confLogs.maxByOrNull { it.t }?.v?.toIntOrNull() ?: 0
            val lastTs = confLogs.maxOfOrNull { it.t } ?: t.updatedAt
            val days = (System.currentTimeMillis() - lastTs) / 86_400_000.0

            // Lower score = more overdue. Never-rated items are highly due.
            val score = when {
                lastConf == 0 -> 0.0
                else -> days / (lastConf * lastConf + 1)
            }
            ReviewItem(t, lastConf, days, score)
        }
            .sortedBy { it.score }
            .take(limit)
    }

    private fun reviewWhy(item: ReviewItem): String = when {
        item.confidence == 0 -> "Never rated — get a baseline"
        item.daysSince > 21 -> "Last rated ${item.daysSince.toInt()} days ago at ${item.confidence}/5"
        item.confidence <= 2 -> "Low confidence (${item.confidence}/5) — short interval"
        else -> "Due for review (${item.confidence}/5, ${item.daysSince.toInt()}d ago)"
    }

    // ── BPM coverage gaps ─────────────────────────────────────────────────────

    data class BpmGap(val label: String, val low: Int, val high: Int)

    fun bpmGaps(allEntries: List<EntryEntity>): List<BpmGap> {
        val bands = listOf(
            BpmGap("under 90", 60, 89),
            BpmGap("90–119", 90, 119),
            BpmGap("120–139", 120, 139),
            BpmGap("140–159", 140, 159),
            BpmGap("160–179", 160, 179),
            BpmGap("180+", 180, 220)
        )
        val used = allEntries.mapNotNull { it.bpm }.toSet()
        return bands.filter { band ->
            used.none { it in band.low..band.high }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun fitToMinutes(blocks: List<DrillBlock>, target: Int): List<DrillBlock> {
        if (blocks.isEmpty()) return blocks
        var total = blocks.sumOf { it.minutes }
        if (total <= target) {
            // Add a free block if we have spare time
            val spare = target - total
            return if (spare >= 4) {
                blocks + DrillBlock(
                    name = "Free — your call",
                    minutes = spare,
                    bpm = 0,
                    click = false,
                    why = "You earned the open minutes. Use them on whatever feels weak today."
                )
            } else blocks
        }
        // Trim from the end (keep fixed warm-up)
        val result = blocks.toMutableList()
        while (result.sumOf { it.minutes } > target && result.size > 1) {
            val last = result.last()
            if (last.fixed) break
            if (last.minutes > 3) {
                result[result.lastIndex] = last.copy(minutes = last.minutes - 1)
            } else {
                result.removeAt(result.lastIndex)
            }
        }
        return result
    }

    private fun genreTempo(name: String): Int {
        val map = mapOf(
            "Drum & Bass" to 174, "D&B" to 174, "Jungle" to 170,
            "Hip-Hop" to 90, "Boom Bap" to 88, "Trap" to 140,
            "Garage" to 130, "UK Garage" to 132, "Grime" to 140,
            "Dubstep" to 140, "House" to 124, "Techno" to 130,
            "Footwork" to 160, "Juke" to 160, "Breakbeat" to 135
        )
        return map.entries.firstOrNull { name.contains(it.key, ignoreCase = true) }?.value ?: 120
    }

    private fun hashStr(s: String): Int {
        var h = 0
        for (c in s) h = (h * 31 + c.code) and 0x7fffffff
        return h
    }

    private data class LogEntry(val t: Long, val k: String, val v: String)

    private fun parseLog(json: String): List<LogEntry> {
        // Minimal tolerant parser for the HTML log format [{t,k,v},...]
        if (json.isBlank() || json == "[]") return emptyList()
        return try {
            val items = mutableListOf<LogEntry>()
            val objRegex = """\{[^}]+\}""".toRegex()
            objRegex.findAll(json).forEach { m ->
                val o = m.value
                val t = """"t"\s*:\s*(\d+)""".toRegex().find(o)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                val k = """"k"\s*:\s*"([^"]+)"""".toRegex().find(o)?.groupValues?.get(1) ?: ""
                val v = """"v"\s*:\s*"([^"]+)"""".toRegex().find(o)?.groupValues?.get(1)
                    ?: """"v"\s*:\s*(\d+)""".toRegex().find(o)?.groupValues?.get(1) ?: ""
                if (k.isNotEmpty()) items += LogEntry(t, k, v)
            }
            items
        } catch (_: Exception) { emptyList() }
    }

    private fun parseJsonList(json: String): List<String> {
        if (json.isBlank() || json == "[]") return emptyList()
        return """"([^"]+)"""".toRegex().findAll(json).map { it.groupValues[1] }.toList()
    }
}
