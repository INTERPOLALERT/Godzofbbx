package com.chamber.beatbox.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.chamber.beatbox.data.audio.MetronomeEngine
import com.chamber.beatbox.data.audio.SequencerEngine
import com.chamber.beatbox.data.audio.VisualizerEngine
import com.chamber.beatbox.data.db.ChamberDatabase
import com.chamber.beatbox.data.db.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "chamber_settings")

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): ChamberDatabase =
        ChamberDatabase.create(ctx)

    @Provides @Singleton fun provideEntryDao(db: ChamberDatabase): EntryDao = db.entryDao()
    @Provides @Singleton fun provideFileMetaDao(db: ChamberDatabase): FileMetaDao = db.fileMetaDao()
    @Provides @Singleton fun providePracticeLogDao(db: ChamberDatabase): PracticeLogDao = db.practiceLogDao()
    @Provides @Singleton fun provideHealthLogDao(db: ChamberDatabase): HealthLogDao = db.healthLogDao()
    @Provides @Singleton fun provideGameStateDao(db: ChamberDatabase): GameStateDao = db.gameStateDao()
    @Provides @Singleton fun provideKvDao(db: ChamberDatabase): KvDao = db.kvDao()

    @Provides @Singleton
    fun provideDataStore(@ApplicationContext ctx: Context): DataStore<Preferences> =
        ctx.dataStore

    // Audio engines are long-lived singletons — they hold AudioTrack/AudioRecord
    // state that must survive configuration changes and screen navigation.
    @Provides @Singleton
    fun provideMetronomeEngine(): MetronomeEngine = MetronomeEngine()

    @Provides @Singleton
    fun provideVisualizerEngine(): VisualizerEngine = VisualizerEngine()

    @Provides @Singleton
    fun provideSequencerEngine(@ApplicationContext ctx: Context): SequencerEngine =
        SequencerEngine(ctx)
}
