package com.chamber.beatbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.chamber.beatbox.data.audio.MetronomeEngine
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.navigation.ChamberNavGraph
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.*
import com.chamber.beatbox.ui.MetroSettingsSync
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var metronomeEngine: MetronomeEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ChamberTheme {
                ChamberApp(metronomeEngine = metronomeEngine)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release the AudioTrack when the app is destroyed (not just paused —
        // the metronome keeps running on pause so the click continues while
        // the user reads another app).
        if (isFinishing) {
            metronomeEngine.release()
        }
    }
}

// ── Root composable ───────────────────────────────────────────────────────────

@Composable
fun ChamberApp(metronomeEngine: MetronomeEngine) {
    val navController = rememberNavController()
    val backEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backEntry?.destination?.route

    var metroVisible by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var quickCaptureOpen by remember { mutableStateOf(false) }
    var searchOpen   by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        MetroSettingsSync()
        Scaffold(
            containerColor = Bg,
            topBar = {
                Column {
                    ChamberTopBar(
                        navController   = navController,
                        metroRunning    = metronomeEngine.isRunningFlow.collectAsStateWithLifecycle().value,
                        onMetroToggle   = { metroVisible = !metroVisible },
                        onSearchToggle  = { navController.navigate(Routes.SEARCH) },
                        onMenuOpen      = { menuOpen = true }
                    )
                    ChamberChipStrip(
                        currentRoute = currentRoute,
                        navController = navController
                    )
                }
            },
        ) { innerPadding ->
            ChamberNavGraph(
                navController = navController,
                modifier = Modifier.padding(innerPadding)
            )
        }

        // Full-screen metro panel (HTML #metro) — overlays content under chrome
        if (metroVisible) {
            MetronomeBar(
                engine = metronomeEngine,
                onClose = { metroVisible = false }
            )
        }

        // Quick Capture FAB — lifts when metro open (body.metro-open .qcfab)
        QuickCaptureFab(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = if (metroVisible) 16.dp else 16.dp),
            onClick = { quickCaptureOpen = true }
        )

        if (menuOpen) {
            FullMenuSheet(
                navController = navController,
                onDismiss = { menuOpen = false }
            )
        }
        ToastHost(Modifier = Modifier.align(Alignment.BottomCenter))

        if (quickCaptureOpen) {
            QuickCaptureSheet(
                onDismiss = { quickCaptureOpen = false },
                onCreated = { id ->
                    quickCaptureOpen = false
                    navController.navigate(Routes.entry(id))
                }
            )
        }
    }
}

// ── Top bar ───────────────────────────────────────────────────────────────────

@Composable
fun ChamberTopBar(
    navController: NavHostController,
    metroRunning: Boolean,
    onMetroToggle: () -> Unit,
    onSearchToggle: () -> Unit,
    onMenuOpen: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(ChamberDimens.TopBarHeight)
            .background(Ink)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Brand
        Text(
            "CHAMBER",
            style    = ChamberType.Brand,
            color    = Color.White,
            modifier = Modifier
                .clickable { navController.navigate(Routes.HOME) { launchSingleTop = true } }
                .padding(horizontal = 6.dp)
        )
        Spacer(Modifier.weight(1f))

        // Metronome toggle — shows a ♩ dot when running
        TopBarIconButton(
            label   = if (metroRunning) "♩●" else "♩",
            onClick = onMetroToggle
        )
        TopBarIconButton("⌕", onSearchToggle)
        TopBarIconButton("≡", onMenuOpen)
    }
}

@Composable
fun TopBarIconButton(label: String, onClick: () -> Unit) {
    // HTML .hb / .hb:active — white border, invert on press
    val interaction = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier = Modifier
            .defaultMinSize(minWidth = 44.dp)
            .height(40.dp)
            .border(2.dp, Color.White)
            .background(if (pressed) Color.White else Color.Transparent)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = ChamberType.BodyBold, color = if (pressed) Color.Black else Color.White)
    }
    Spacer(Modifier.width(6.dp))
}

// ── Chip strip ────────────────────────────────────────────────────────────────

@Composable
fun ChamberChipStrip(
    currentRoute: String?,
    navController: NavHostController
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(ChamberDimens.StripHeight)
            .background(Bg)
            .drawBehind {
                drawLine(Ink, Offset(0f, size.height - 4f),
                    Offset(size.width, size.height - 4f), strokeWidth = 4f)
            }
            .horizontalScroll(scrollState)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Routes.chipSections.forEach { sec ->
            val isActive = currentRoute == sec.route ||
                (currentRoute?.startsWith("e/") == true) // TODO: match by entry kind

            SectionChip(
                glyph    = sec.glyph,
                title    = sec.title,
                isActive = isActive,
                onClick  = { navController.navigate(sec.route) { launchSingleTop = true } }
            )
        }
    }
}

@Composable
fun SectionChip(
    glyph: String,
    title: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    // Matches HTML .chip / .chip.on — inverted fill when active, weight 800
    Box(
        modifier = Modifier
            .border(2.dp, Ink)
            .background(if (isActive) Ink else Bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
            .defaultMinSize(minHeight = 36.dp),
        contentAlignment = Alignment.Center
    ) {
        // HTML chips show glyph only; title is in native tooltip via long-press not needed
        Text(
            glyph,
            style    = ChamberType.ButtonSm,
            color    = if (isActive) Bg else Ink,
            maxLines = 1,
            overflow = TextOverflow.Clip
        )
    }
}

// ── Metronome bar ─────────────────────────────────────────────────────────────


@Composable
fun MetronomeBar(
    engine: MetronomeEngine,
    onClose: () -> Unit
) {
    // HTML #metro: fixed left/right, top under header, bottom 0, black, full panel
    var activeBeat by remember { mutableStateOf(-1) }
    var isMuted by remember { mutableStateOf(false) }
    var showBpmInput by remember { mutableStateOf(false) }
    var bpmDraft by remember { mutableStateOf(engine.bpm.toString()) }

    LaunchedEffect(engine) {
        engine.beatFlow.collect { event ->
            activeBeat = event.beatIndex
            isMuted = event.isMuted
        }
    }

    val running = engine.isRunningFlow.collectAsStateWithLifecycle().value

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable(onClick = onClose)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(top = 0.dp) // sits under scaffold top bar already
                .background(Color.Black)
                .border(width = 0.dp, color = Color.Black)
                .clickable(enabled = false) {}
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header row
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("METRONOME", style = ChamberType.Brand, color = Color.White, modifier = Modifier.weight(1f))
                Box(
                    Modifier.size(36.dp).border(2.dp, Color.White).clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✕", style = ChamberType.ButtonSm, color = Color.White)
                }
            }

            // Transport + BPM
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetroButton(if (running) "■ STOP" else "▶ START", onClick = engine::toggle, modifier = Modifier.width(100.dp))
                MetroButton("−", onClick = { engine.setBpm(engine.bpm - 1) })
                Box(
                    Modifier
                        .defaultMinSize(minWidth = 76.dp, minHeight = 44.dp)
                        .clickable {
                            bpmDraft = engine.bpm.toString()
                            showBpmInput = true
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(engine.bpm.toString(), style = ChamberType.Bpm, color = Color.White)
                }
                MetroButton("+", onClick = { engine.setBpm(engine.bpm + 1) })
                MetroButton("TAP", onClick = engine::tap, modifier = Modifier.width(60.dp))
            }

            if (showBpmInput) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChamberField(
                        bpmDraft,
                        { bpmDraft = it.filter { ch -> ch.isDigit() }.take(3) },
                        placeholder = "BPM",
                        modifier = Modifier.weight(1f)
                    )
                    ChamberButton("SET", onClick = {
                        bpmDraft.toIntOrNull()?.let { engine.setBpm(it) }
                        showBpmInput = false
                    }, size = ButtonSize.Small)
                    ChamberButton("✕", onClick = { showBpmInput = false }, size = ButtonSize.ExtraSmall)
                }
            }

            // Beat dots
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (i in 0 until engine.beats) {
                    val isActive = activeBeat == i
                    val isAccent = i == 0
                    val dotSize = if (isAccent) ChamberDimens.BeatDotAccent else ChamberDimens.BeatDotNormal
                    Box(
                        Modifier
                            .size(dotSize)
                            .border(2.dp, if (isMuted) Color.White.copy(alpha = 0.5f) else Color.White)
                            .background(
                                when {
                                    isMuted -> Color.Transparent
                                    isActive -> Color.White
                                    else -> Color.Transparent
                                }
                            )
                    )
                }
                Spacer(Modifier.weight(1f))
                MetroToggle("${engine.beats}/4", onClick = {
                    val opts = listOf(2, 3, 4, 5, 6, 7)
                    engine.setBeats(opts[(opts.indexOf(engine.beats) + 1) % opts.size])
                })
                MetroToggle("ACCENT", active = engine.accent, onClick = { engine.accent = !engine.accent })
                MetroToggle("SOUND", active = engine.audible, onClick = { engine.audible = !engine.audible })
            }

            // Bounce ball
            BounceBall(
                running = running,
                bpm = engine.bpm,
                activeBeat = activeBeat,
                beats = engine.beats
            )

            // Gap trainer + ramp (HTML advanced metro)
            Text("GAP TRAINER", style = ChamberType.MonoLabel, color = Color.White.copy(alpha = 0.7f))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MetroToggle(
                    if (engine.gapEnabled) "GAP ON ${engine.gapPlayBars}/${engine.gapMuteBars}" else "GAP OFF",
                    active = engine.gapEnabled,
                    onClick = { engine.gapEnabled = !engine.gapEnabled }
                )
                MetroButton("PLAY+", onClick = { engine.gapPlayBars = (engine.gapPlayBars + 1).coerceAtMost(16) })
                MetroButton("MUTE+", onClick = { engine.gapMuteBars = (engine.gapMuteBars + 1).coerceAtMost(8) })
            }

            Text("BPM RAMP", style = ChamberType.MonoLabel, color = Color.White.copy(alpha = 0.7f))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MetroToggle(
                    if (engine.rampEnabled) "RAMP ON →${engine.rampMaxBpm}" else "RAMP OFF",
                    active = engine.rampEnabled,
                    onClick = { engine.rampEnabled = !engine.rampEnabled }
                )
                MetroButton("MAX+", onClick = { engine.rampMaxBpm = (engine.rampMaxBpm + 5).coerceAtMost(300) })
                MetroButton("STEP+", onClick = { engine.rampStepBpm = (engine.rampStepBpm + 1).coerceAtMost(10) })
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Same idea as HTML metro panel — full black sheet under the top bar. Tap outside or ✕ to close.",
                style = ChamberType.Mono,
                color = Color.White.copy(alpha = 0.45f)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}


@Composable
private fun BounceBall(
    running: Boolean,
    bpm: Int,
    activeBeat: Int,
    beats: Int
) {
    val periodMs = (60_000f / bpm.coerceIn(30, 300)).toInt()
    var phase by remember { mutableStateOf(0f) }

    LaunchedEffect(running, bpm, activeBeat) {
        if (!running) {
            phase = 0f
            return@LaunchedEffect
        }
        val start = System.currentTimeMillis()
        while (true) {
            val elapsed = (System.currentTimeMillis() - start) % periodMs
            // 0 at beat, rises then falls (parabola) across the beat interval
            val t = elapsed / periodMs.toFloat()
            phase = 4f * t * (1f - t)  // peak mid-interval
            delay(16)
        }
    }

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .border(2.dp, Color.White.copy(alpha = 0.4f))
    ) {
        val r = 8.dp.toPx()
        val x = size.width / 2f
        val ground = size.height - r - 4.dp.toPx()
        val peak = r + 4.dp.toPx()
        val y = ground - (ground - peak) * phase
        drawCircle(Color.White, radius = r, center = Offset(x, y))
        // floor line
        drawLine(
            Color.White.copy(alpha = 0.35f),
            Offset(16.dp.toPx(), ground + r),
            Offset(size.width - 16.dp.toPx(), ground + r),
            strokeWidth = 2.dp.toPx()
        )
    }
}

@Composable
private fun MetroButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .border(2.dp, Color.White)
            .defaultMinSize(minHeight = 40.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = ChamberType.ButtonSm, color = Color.White)
    }
}

@Composable
private fun MetroToggle(
    label: String,
    active: Boolean = true,
    onClick: () -> Unit
) {
    val alpha = if (active) 1f else 0.45f
    Box(
        modifier = Modifier
            .border(2.dp, Color.White.copy(alpha = alpha))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 8.dp)
            .defaultMinSize(minHeight = 38.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = ChamberType.ButtonSm,
            color = Color.White.copy(alpha = alpha))
    }
}

// ── Quick Capture FAB ─────────────────────────────────────────────────────────

@Composable
fun QuickCaptureFab(modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    // HTML .qcfab: box-shadow 5px 5px 0 #000
    Box(
        modifier = modifier
            .drawBehind {
                drawRect(
                    color = Ink,
                    topLeft = Offset(5.dp.toPx(), 5.dp.toPx()),
                    size = size
                )
            }
            .border(2.dp, Ink)
            .background(Bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("● QC", style = ChamberType.Button, color = Ink)
    }
}

@Composable
fun FullMenuSheet(navController: NavHostController, onDismiss: () -> Unit) {
    val c = LocalChamberColors.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable(onClick = onDismiss)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .align(Alignment.BottomCenter)
                .background(c.bg)
                .border(3.dp, c.ink)
                .clickable(enabled = false) {}
                .padding(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ALL SECTIONS", style = ChamberType.Brand, color = c.ink, modifier = Modifier.weight(1f))
                Box(
                    Modifier.size(36.dp).border(2.dp, c.ink).clickable(onClick = onDismiss),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✕", style = ChamberType.ButtonSm, color = c.ink)
                }
            }
            Spacer(Modifier.height(10.dp))
            androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize()) {
                Routes.groups.forEach { group ->
                    item {
                        Text(group, style = ChamberType.MonoLabel, color = c.muted,
                            modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    }
                    Routes.sections.filter { it.group == group }.forEach { sec ->
                        item {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .border(2.dp, c.ink)
                                    .clickable {
                                        navController.navigate(sec.route) {
                                            launchSingleTop = true
                                        }
                                        onDismiss()
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(sec.glyph, style = ChamberType.Brand, color = c.ink, modifier = Modifier.width(44.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(sec.title.uppercase(), style = ChamberType.BodyBold, color = c.ink)
                                    Text(sec.desc, style = ChamberType.MonoTiny, color = c.muted, maxLines = 1)
                                }
                            }
                            Spacer(Modifier.height(2.dp))
                        }
                    }
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
}

@Composable
fun QuickCaptureSheet(
    onDismiss: () -> Unit,
    onCreated: (String) -> Unit,
    vm: com.chamber.beatbox.ui.screens.qc.QuickCaptureViewModel = androidx.hilt.navigation.compose.hiltViewModel()
) {
    val c = LocalChamberColors.current
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("idea") }
    val kinds = listOf("idea", "oneshot", "technique", "bars", "champ", "pattern")

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onDismiss)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(c.bg)
                .border(3.dp, c.ink)
                .clickable(enabled = false) {}
                .padding(16.dp)
        ) {
            Text("QUICK CAPTURE", style = ChamberType.Brand, color = c.ink)
            Spacer(Modifier.height(6.dp))
            Text("Same as HTML ● QC — dump an idea before it evaporates.", style = ChamberType.Mono, color = c.muted)
            Spacer(Modifier.height(10.dp))
            Text("KIND", style = ChamberType.MonoLabel, color = c.muted)
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                kinds.forEach { k ->
                    val on = kind == k
                    Box(
                        Modifier.border(2.dp, c.ink).background(if (on) c.ink else c.bg)
                            .clickable { kind = k }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(k.uppercase(), style = ChamberType.ButtonSm, color = if (on) c.bg else c.ink)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            ChamberField(name, { name = it }, placeholder = "Name…", modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            ChamberButton(
                "CREATE",
                onClick = { vm.create(kind, name, onCreated) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            ChamberButton("CANCEL", onClick = onDismiss, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
        }
    }
}
