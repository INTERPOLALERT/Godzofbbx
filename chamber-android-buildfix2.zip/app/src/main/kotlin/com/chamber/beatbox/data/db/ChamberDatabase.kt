package com.chamber.beatbox.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.chamber.beatbox.data.db.converters.StringListConverter
import com.chamber.beatbox.data.db.dao.*
import com.chamber.beatbox.data.db.entities.*

@Database(
    entities = [
        EntryEntity::class,
        FileMetaEntity::class,
        PracticeLogEntity::class,
        HealthLogEntity::class,
        GameStateEntity::class,
        KvEntity::class
    ],
    version       = 1,
    exportSchema  = true   // writes schemas/ for migration tracking
)
@TypeConverters(StringListConverter::class)
abstract class ChamberDatabase : RoomDatabase() {

    abstract fun entryDao(): EntryDao
    abstract fun fileMetaDao(): FileMetaDao
    abstract fun practiceLogDao(): PracticeLogDao
    abstract fun healthLogDao(): HealthLogDao
    abstract fun gameStateDao(): GameStateDao
    abstract fun kvDao(): KvDao

    companion object {
        const val DB_NAME = "chamber.db"

        // Room requires only one instance; DI module handles this.
        fun create(context: Context): ChamberDatabase =
            Room.databaseBuilder(context, ChamberDatabase::class.java, DB_NAME)
                // fallbackToDestructiveMigration should be removed once the app
                // ships to real users — replace with explicit Migration objects.
                .fallbackToDestructiveMigration()
                .build()
    }
}
