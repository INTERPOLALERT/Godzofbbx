package com.chamber.beatbox.ui.screens.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.db.dao.GameStateDao
import com.chamber.beatbox.data.db.dao.KvDao
import com.chamber.beatbox.data.db.dao.PracticeLogDao
import com.chamber.beatbox.data.db.entities.*
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class DataUiState(
    val trashCount: Int        = 0,
    val totalStorageBytes: Long = 0L,
    val entryCount: Int        = 0,
    val fileCount: Int         = 0,
    val eventName: String      = "",
    val eventDate: String      = "",
    val isExporting: Boolean   = false,
    val isImporting: Boolean   = false,
    val lastMessage: String    = "",
    val trashedEntries: List<EntryEntity> = emptyList()
)

@HiltViewModel
class DataViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repo: EntryRepository,
    private val gameStateDao: GameStateDao,
    private val practiceLogDao: PracticeLogDao,
    private val kvDao: KvDao,
    private val settings: SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(DataUiState())
    val uiState: StateFlow<DataUiState> = _state.asStateFlow()

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true; encodeDefaults = true }

    init {
        viewModelScope.launch {
            combine(
                repo.observeTrashed(),
                repo.observeTotalStorageBytes(),
                repo.observeAll(),
                settings.eventName,
                settings.eventDate
            ) { trashed, storageBytes, all, eventName, eventDate ->
                _state.update { it.copy(
                    trashCount         = trashed.size,
                    trashedEntries     = trashed,
                    totalStorageBytes  = storageBytes,
                    entryCount         = all.size,
                    eventName          = eventName,
                    eventDate          = eventDate
                )}
            }.collect()
        }
    }

    fun setEventName(v: String) {
        viewModelScope.launch { settings.setEventName(v) }
    }

    fun setEventDate(v: String) {
        viewModelScope.launch { settings.setEventDate(v) }
    }

    fun clearEvent() {
        viewModelScope.launch {
            settings.setEventName("")
            settings.setEventDate("")
        }
    }

    // ── Export ────────────────────────────────────────────────────────────────

    /**
     * Exports all data to a JSON file in the app cache dir, then launches the
     * Android share sheet. Media files (recordings) are listed by path but
     * not bundled — a ZIP export with media is a future enhancement.
     */
    fun exportJson() {
        viewModelScope.launch {
            _state.update { it.copy(isExporting = true, lastMessage = "Preparing export…") }
            try {
                val exportObj = buildExportJson()
                val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val cacheDir = File(context.cacheDir, "exports").also { it.mkdirs() }
                val file = File(cacheDir, "chamber_backup_$ts.json")
                file.writeText(json.encodeToString(exportObj))

                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(intent, "Export CHAMBER Backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                _state.update { it.copy(isExporting = false, lastMessage = "Export ready — ${file.length() / 1024} KB") }
            } catch (e: Exception) {
                _state.update { it.copy(isExporting = false, lastMessage = "Export failed: ${e.message}") }
            }
        }
    }

    /**
     * Imports from a URI (picked via document picker).
     * Entries that already exist (same ID) are updated; new ones are inserted.
     */
    fun importJson(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(isImporting = true, lastMessage = "Importing…") }
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
                    ?: throw Exception("Could not read file")
                val obj = json.parseToJsonElement(text).jsonObject

                // Import entries
                val entriesArr = obj["entries"]?.jsonArray ?: JsonArray(emptyList())
                val entries = entriesArr.map { decodeEntry(it.jsonObject) }
                repo.upsertAll(entries)

                // Import game state
                obj["gameState"]?.jsonObject?.let { gs ->
                    gameStateDao.upsert(GameStateEntity(
                        xp         = gs["xp"]?.jsonPrimitive?.int ?: 0,
                        questJson  = gs["questJson"]?.jsonPrimitive?.content ?: "{}",
                        badgesJson = gs["badgesJson"]?.jsonPrimitive?.content ?: "[]"
                    ))
                }

                val count = entries.size
                _state.update { it.copy(isImporting = false, lastMessage = "Imported $count entries ✓") }
            } catch (e: Exception) {
                _state.update { it.copy(isImporting = false, lastMessage = "Import failed: ${e.message}") }
            }
        }
    }

    // ── Trash management ──────────────────────────────────────────────────────

    fun restoreEntry(id: String) { viewModelScope.launch { repo.restore(id) } }

    fun purgeEntry(id: String) { viewModelScope.launch { repo.purge(id) } }

    fun purgeAllTrashed() { viewModelScope.launch { repo.purgeAllTrashed() } }

    fun clearMessage() { _state.update { it.copy(lastMessage = "") } }

    // ── JSON builder ──────────────────────────────────────────────────────────

    private suspend fun buildExportJson(): JsonObject {
        val allEntries = repo.observeAll().first()
        val allSessions = practiceLogDao.getRecent(1000).first()
        val gameState = gameStateDao.get() ?: GameStateEntity()
        val settingsSnapshot = settings.snapshot()

        return buildJsonObject {
            put("version", "1.4.1")
            put("exportedAt", System.currentTimeMillis())
            putJsonArray("entries") { allEntries.forEach { add(encodeEntry(it)) } }
            putJsonArray("sessions") {
                allSessions.forEach { s -> add(buildJsonObject {
                    put("type", s.type); put("day", s.day); put("timestamp", s.timestamp)
                    put("minutes", s.minutes); put("focus", s.focus)
                    s.rating?.let { put("rating", it) }; s.bpm?.let { put("bpm", it) }
                })}
            }
            put("gameState", buildJsonObject {
                put("xp", gameState.xp)
                put("questJson", gameState.questJson)
                put("badgesJson", gameState.badgesJson)
            })
            put("settings", buildJsonObject {
                settingsSnapshot.forEach { (k, v) -> put(k, v?.toString() ?: "") }
            })
        }
    }

    private fun encodeEntry(e: EntryEntity): JsonObject = buildJsonObject {
        put("id", e.id); put("kind", e.kind); put("name", e.name)
        put("createdAt", e.createdAt); put("updatedAt", e.updatedAt)
        put("deleted", e.deleted); put("pin", e.pin)
        e.bpm?.let { put("bpm", it) }; e.status?.let { put("status", it) }
        e.cat?.let { put("cat", it) }; e.bars?.let { put("bars", it) }
        e.notes?.let { put("notes", it) }; e.description?.let { put("description", it) }
        put("links", e.links); put("log", e.log); put("tags", e.tags); put("extraJson", e.extraJson)
    }

    private fun decodeEntry(obj: JsonObject): EntryEntity = EntryEntity(
        id          = obj["id"]?.jsonPrimitive?.content ?: return EntryEntity("","",""),
        kind        = obj["kind"]?.jsonPrimitive?.content ?: "idea",
        name        = obj["name"]?.jsonPrimitive?.content ?: "",
        createdAt   = obj["createdAt"]?.jsonPrimitive?.long ?: System.currentTimeMillis(),
        updatedAt   = obj["updatedAt"]?.jsonPrimitive?.long ?: System.currentTimeMillis(),
        deleted     = obj["deleted"]?.jsonPrimitive?.boolean ?: false,
        pin         = obj["pin"]?.jsonPrimitive?.boolean ?: false,
        bpm         = obj["bpm"]?.jsonPrimitive?.intOrNull,
        status      = obj["status"]?.jsonPrimitive?.contentOrNull,
        cat         = obj["cat"]?.jsonPrimitive?.contentOrNull,
        bars        = obj["bars"]?.jsonPrimitive?.intOrNull,
        notes       = obj["notes"]?.jsonPrimitive?.contentOrNull,
        description = obj["description"]?.jsonPrimitive?.contentOrNull,
        links       = obj["links"]?.jsonPrimitive?.content ?: "[]",
        log         = obj["log"]?.jsonPrimitive?.content ?: "[]",
        tags        = obj["tags"]?.jsonPrimitive?.content ?: "[]",
        extraJson   = obj["extraJson"]?.jsonPrimitive?.content ?: "{}"
    )
}
