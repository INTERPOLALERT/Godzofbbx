package com.chamber.beatbox.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.SystemClock
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton
import com.chamber.beatbox.R

/**
 * Step sequencer engine using SoundPool.
 *
 * Timing: coroutine-based timer on URGENT_AUDIO priority thread.
 * At 120 BPM, 16th note = 125 ms; step-interval error from scheduling
 * jitter is tolerable for a pattern lab (not metronome accuracy needed).
 *
 * Kit sounds: loaded from res/raw/. Filenames documented below.
 * If the files are absent, the engine silently skips playback.
 *
 * Grid format matches the extraJson.grid field in EntryEntity:
 *   {"kick":[false,true,...], "snare":[...], "hat":[...], "bass":[...], "extra":[...]}
 *
 * Sound files to add in res/raw/:
 *   seq_kick.wav, seq_snare.wav, seq_hat.wav, seq_bass.wav, seq_extra.wav
 *   seq_click_accent.wav, seq_click_normal.wav (for plain-click fallback)
 */
@Singleton
class SequencerEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        val LANES = listOf("kick", "snare", "hat", "bass", "extra")
        const val DEFAULT_STEPS = 16
    }

    // ── Public state ──────────────────────────────────────────────────────────
    var bpm: Int = 120
        set(v) { field = v.coerceIn(30, 300) }

    /** step resolution: 4 = 1/16 notes (16 steps/bar), 2 = 1/8 (8 steps/bar) */
    var resolution: Int = 4

    /** Swing amount 0.0–1.0, applied to off-beat steps */
    var swing: Float = 0f

    /** True = lane audio is silenced but step still advances */
    val mutedLanes: MutableSet<String> = mutableSetOf()

    /** Grid: laneName → BooleanArray of [step0..stepN-1] */
    var grid: Map<String, BooleanArray> = LANES.associateWith { BooleanArray(DEFAULT_STEPS) }

    private val _currentStep = MutableStateFlow(-1)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    // ── SoundPool ─────────────────────────────────────────────────────────────
    private var soundPool: SoundPool? = null
    private val soundIds = mutableMapOf<String, Int>()
    private var poolReady = false

    // ── Playback ───────────────────────────────────────────────────────────────
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var playJob: Job? = null

    fun load() {
        if (poolReady) return
        val pool = SoundPool.Builder()
            .setMaxStreams(6)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        soundPool = pool

        // Load kit sounds — map lane name → raw resource id.
        // Add the .wav files to res/raw/ with these exact names.
        // If a resource is missing, the lane simply makes no sound.
        val resMap = mapOf(
            "kick"  to R.raw.seq_kick,
            "snare" to R.raw.seq_snare,
            "hat"   to R.raw.seq_hat,
            "bass"  to R.raw.seq_bass,
            "extra" to R.raw.seq_extra
        )
        for ((lane, resId) in resMap) {
            runCatching { soundIds[lane] = pool.load(context, resId, 1) }
        }
        poolReady = true
    }

    fun start() {
        if (_isPlaying.value) return
        load()
        _isPlaying.value = true
        val steps = grid.values.firstOrNull()?.size ?: DEFAULT_STEPS
        var step = 0

        playJob = scope.launch {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            var nextTick = SystemClock.elapsedRealtimeNanos()

            while (isActive && _isPlaying.value) {
                // Step interval in nanoseconds
                // resolution = subdivision factor: 4 → 1/16, 2 → 1/8
                val stepNs = (60_000_000_000L / bpm.toLong() / resolution.toLong())
                // Swing: odd steps (0-indexed) pushed by swing*stepNs*0.15
                val swingNs = if (step % 2 == 1) (swing * stepNs * 0.15).toLong() else 0L

                // Fire sounds for this step
                fireStep(step)
                _currentStep.value = step

                step = (step + 1) % steps

                // Busy-wait until next tick (more accurate than delay() for tight loops)
                nextTick += stepNs + swingNs
                val now = SystemClock.elapsedRealtimeNanos()
                val sleepMs = (nextTick - now) / 1_000_000L
                if (sleepMs > 0) delay(sleepMs)
            }
        }
    }

    fun stop() {
        playJob?.cancel(); playJob = null
        _isPlaying.value = false
        _currentStep.value = -1
    }

    fun toggle() { if (_isPlaying.value) stop() else start() }

    fun release() { stop(); soundPool?.release(); soundPool = null; scope.cancel() }

    // ── Step helpers ──────────────────────────────────────────────────────────

    /** Toggle a single cell in the grid. Returns the new grid. */
    fun toggleCell(lane: String, step: Int): Map<String, BooleanArray> {
        val newGrid = grid.mapValues { (k, arr) ->
            if (k == lane) {
                arr.copyOf().also { it[step] = !it[step] }
            } else arr
        }
        grid = newGrid
        return newGrid
    }

    fun clearLane(lane: String) {
        grid = grid.mapValues { (k, arr) ->
            if (k == lane) BooleanArray(arr.size) else arr
        }
    }

    fun clearAll() {
        grid = LANES.associateWith { BooleanArray(grid.values.firstOrNull()?.size ?: DEFAULT_STEPS) }
    }

    fun setStepCount(steps: Int) {
        val validSteps = steps.coerceIn(8, 64)
        grid = LANES.associateWith { lane ->
            val existing = grid[lane] ?: BooleanArray(validSteps)
            if (existing.size == validSteps) existing
            else BooleanArray(validSteps) { i -> existing.getOrElse(i) { false } }
        }
    }

    // ── Sound playback ────────────────────────────────────────────────────────

    private fun fireStep(step: Int) {
        val pool = soundPool ?: return
        for (lane in LANES) {
            val active = grid[lane]?.getOrElse(step) { false } ?: false
            if (!active || lane in mutedLanes) continue
            val sndId = soundIds[lane] ?: continue
            pool.play(sndId, 1f, 1f, 1, 0, 1f)
        }
    }

    // ── Grid JSON serialization (used by EntryViewModel) ─────────────────────

    fun gridToJson(): String {
        val sb = StringBuilder("{")
        LANES.forEachIndexed { li, lane ->
            val arr = grid[lane] ?: BooleanArray(DEFAULT_STEPS)
            sb.append("\"$lane\":[")
            arr.forEachIndexed { i, v -> sb.append(if (v) "true" else "false"); if (i < arr.size - 1) sb.append(",") }
            sb.append("]")
            if (li < LANES.size - 1) sb.append(",")
        }
        sb.append("}")
        return sb.toString()
    }

    fun loadGridFromJson(json: String) {
        if (json.isBlank() || json == "{}") { clearAll(); return }
        try {
            val newGrid = mutableMapOf<String, BooleanArray>()
            val steps = DEFAULT_STEPS
            for (lane in LANES) {
                val laneStart = json.indexOf("\"$lane\":[")
                if (laneStart < 0) { newGrid[lane] = BooleanArray(steps); continue }
                val arrStart = json.indexOf("[", laneStart) + 1
                val arrEnd = json.indexOf("]", arrStart)
                val arrStr = json.substring(arrStart, arrEnd)
                val cells = arrStr.split(",")
                newGrid[lane] = BooleanArray(cells.size) { i -> cells.getOrElse(i) { "false" }.trim() == "true" }
            }
            grid = newGrid
        } catch (_: Exception) { clearAll() }
    }
}
