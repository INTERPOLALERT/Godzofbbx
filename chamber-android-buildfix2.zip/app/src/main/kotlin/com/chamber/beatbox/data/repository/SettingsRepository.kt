package com.chamber.beatbox.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Typed accessors for all persistent settings.
 * Keys mirror the HTML's SET object exactly so that a JSON import can
 * populate DataStore without a mapping layer.
 *
 * Complex state (PLOG, HLOG, GAME, quest states) lives in Room;
 * simple scalar preferences live here.
 */
@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {
    private object Keys {
        val BPM            = intPreferencesKey("bpm")
        val BEATS          = intPreferencesKey("beats")
        val SWING          = floatPreferencesKey("swing")
        val COUNT_IN       = intPreferencesKey("countIn")
        val KIT_ON         = booleanPreferencesKey("kitOn")
        val METRO_DIV      = intPreferencesKey("metroDiv")
        val DRILL_MIN      = intPreferencesKey("drillMin")
        val EVENT_DATE     = stringPreferencesKey("eventDate")
        val EVENT_NAME     = stringPreferencesKey("eventName")
        val LAST_WARM      = stringPreferencesKey("lastWarm")
        val GENRES_SEEDED  = booleanPreferencesKey("genresSeeded")
        val GODMODE_POSN   = stringPreferencesKey("godmodePositions")  // JSON
    }

    // ── Flows ─────────────────────────────────────────────────────────────────

    val bpm: Flow<Int>     = pref(Keys.BPM, 100)
    val beats: Flow<Int>   = pref(Keys.BEATS, 4)
    val swing: Flow<Float> = pref(Keys.SWING, 0f)
    val countIn: Flow<Int> = pref(Keys.COUNT_IN, 0)
    val kitOn: Flow<Boolean> = pref(Keys.KIT_ON, false)
    val metroDiv: Flow<Int>  = pref(Keys.METRO_DIV, 1)
    val drillMin: Flow<Int>  = pref(Keys.DRILL_MIN, 30)
    val eventDate: Flow<String> = pref(Keys.EVENT_DATE, "")
    val eventName: Flow<String> = pref(Keys.EVENT_NAME, "")
    val lastWarm: Flow<String>  = pref(Keys.LAST_WARM, "")
    val genresSeeded: Flow<Boolean> = pref(Keys.GENRES_SEEDED, false)

    // ── Setters ───────────────────────────────────────────────────────────────

    suspend fun setBpm(v: Int)       = set(Keys.BPM, v.coerceIn(30, 300))
    suspend fun setBeats(v: Int)     = set(Keys.BEATS, v.coerceIn(2, 7))
    suspend fun setSwing(v: Float)   = set(Keys.SWING, v.coerceIn(0f, 1f))
    suspend fun setCountIn(v: Int)   = set(Keys.COUNT_IN, v.coerceIn(0, 4))
    suspend fun setKitOn(v: Boolean) = set(Keys.KIT_ON, v)
    suspend fun setMetroDiv(v: Int)  = set(Keys.METRO_DIV, v)
    suspend fun setDrillMin(v: Int)  = set(Keys.DRILL_MIN, v)
    suspend fun setEventDate(v: String) = set(Keys.EVENT_DATE, v)
    suspend fun setEventName(v: String) = set(Keys.EVENT_NAME, v)
    suspend fun setLastWarm(v: String)  = set(Keys.LAST_WARM, v)
    suspend fun setGenresSeeded(v: Boolean) = set(Keys.GENRES_SEEDED, v)
    suspend fun setGodmodePositions(json: String) = set(Keys.GODMODE_POSN, json)

    suspend fun snapshot(): Map<String, Any?> {
        return dataStore.data.catch { emit(emptyPreferences()) }.map { prefs ->
            mapOf(
                "bpm"          to (prefs[Keys.BPM] ?: 100),
                "beats"        to (prefs[Keys.BEATS] ?: 4),
                "swing"        to (prefs[Keys.SWING] ?: 0f),
                "countIn"      to (prefs[Keys.COUNT_IN] ?: 0),
                "kitOn"        to (prefs[Keys.KIT_ON] ?: false),
                "drillMin"     to (prefs[Keys.DRILL_MIN] ?: 30),
                "eventDate"    to (prefs[Keys.EVENT_DATE] ?: ""),
                "eventName"    to (prefs[Keys.EVENT_NAME] ?: ""),
                "lastWarm"     to (prefs[Keys.LAST_WARM] ?: "")
            )
        }.catch { emit(emptyMap()) }.let { flow ->
            var result: Map<String, Any?> = emptyMap()
            flow.collect { result = it }
            result
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun <T> pref(key: Preferences.Key<T>, default: T): Flow<T> =
        dataStore.data
            .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
            .map { it[key] ?: default }

    private suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        dataStore.edit { it[key] = value }
    }
}
