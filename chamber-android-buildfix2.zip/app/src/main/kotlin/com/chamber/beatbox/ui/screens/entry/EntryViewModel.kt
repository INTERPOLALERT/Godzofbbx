package com.chamber.beatbox.ui.screens.entry

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.audio.MetronomeEngine
import com.chamber.beatbox.data.audio.RecorderEngine
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.db.entities.FileMetaEntity
import com.chamber.beatbox.data.repository.EntryRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.*
import java.io.File

private val json = Json { ignoreUnknownKeys = true; isLenient = true; encodeDefaults = true }

data class LogEntry(val d: String, val t: Long, val k: String, val v: String)

data class EntryUiState(
    val entry: EntryEntity               = EntryEntity("", "", ""),
    val extra: Map<String, String>       = emptyMap(),
    val log: List<LogEntry>              = emptyList(),
    val files: List<FileMetaEntity>      = emptyList(),
    val linkedEntries: List<EntryEntity> = emptyList(),
    // Recording
    val recorderState: RecorderEngine.State = RecorderEngine.State.Idle,
    val recordingMs: Long                = 0L,
    // Link picker
    val allEntriesForPicker: List<EntryEntity> = emptyList(),
    val showLinkPicker: Boolean          = false,
    // Playback — which file ID is currently playing
    val playingFileId: String?           = null
)

private data class CoreData(
    val entry: EntryEntity, val files: List<FileMetaEntity>,
    val recState: RecorderEngine.State, val recMs: Long, val playingId: String?
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel(assistedFactory = EntryViewModel.Factory::class)
class EntryViewModel @AssistedInject constructor(
    @ApplicationContext private val context: Context,
    private val repo: EntryRepository,
    val metronome: MetronomeEngine,
    private val recorder: RecorderEngine,
    @Assisted val entryId: String
) : ViewModel() {

    @AssistedFactory
    interface Factory { fun create(entryId: String): EntryViewModel }

    private val _pendingEntry = MutableSharedFlow<EntryEntity>(
        replay = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    val entry: StateFlow<EntryEntity?> = repo.observeById(entryId)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _recordingMs = MutableStateFlow(0L)
    private val _showLinkPicker = MutableStateFlow(false)
    private val _playingFileId = MutableStateFlow<String?>(null)

    // Combine in two steps — Flow.combine() supports max 5 sources
    private val _coreFlow = combine(
        entry.filterNotNull(),
        repo.observeFilesForEntry(entryId),
        recorder.state,
        _recordingMs,
        _playingFileId
    ) { e, fList, recState, recMs, playingId ->
        CoreData(e, fList, recState, recMs, playingId)
    }

    private val _pickerFlow = combine(
        _showLinkPicker,
        repo.observeAll()
    ) { show, all -> show to all }

    val uiState: StateFlow<EntryUiState> = combine(_coreFlow, _pickerFlow) { core, (showPicker, allEntries) ->
        val linkedIds = parseJsonStringArray(core.entry.links)
        val linked    = allEntries.filter { it.id in linkedIds && !it.deleted }
        EntryUiState(
            entry               = core.entry,
            extra               = parseExtra(core.entry.extraJson),
            log                 = parseLog(core.entry.log),
            files               = core.files,
            linkedEntries       = linked,
            recorderState       = core.recState,
            recordingMs         = core.recMs,
            allEntriesForPicker = allEntries.filter { it.id != entryId && !it.deleted },
            showLinkPicker      = showPicker,
            playingFileId       = core.playingId
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EntryUiState())

    init {
        viewModelScope.launch {
            _pendingEntry.debounce(500).collect { repo.upsert(it) }
        }
        // Drive the recording timer
        viewModelScope.launch {
            var startMs = 0L
            recorder.state.collect { st ->
                when (st) {
                    is RecorderEngine.State.Recording -> {
                        startMs = System.currentTimeMillis() - _recordingMs.value
                        while (isActive && recorder.isRecording) {
                            _recordingMs.value = System.currentTimeMillis() - startMs
                            delay(200)
                        }
                    }
                    is RecorderEngine.State.Idle -> _recordingMs.value = 0L
                    else -> Unit
                }
            }
        }
    }

    // ── Entry edits ───────────────────────────────────────────────────────────

    fun updateName(name: String)      = edit { it.copy(name = name) }
    fun updateBpm(bpmStr: String)     = edit { it.copy(bpm = bpmStr.trim().toIntOrNull()) }
    fun updateStatus(status: String)  = edit { it.copy(status = status) }

    fun updateExtraField(key: String, value: String) = edit {
        val extra = parseExtra(it.extraJson).toMutableMap()
        extra[key] = value
        it.copy(extraJson = json.encodeToString(extra))
    }

    fun updateTagField(key: String, values: List<String>) = edit {
        val extra = parseExtra(it.extraJson).toMutableMap()
        extra[key] = json.encodeToString(values)
        it.copy(extraJson = json.encodeToString(extra))
    }

    fun addRating(key: String, value: Int) {
        val e = entry.value ?: return
        val today = java.time.LocalDate.now().toString()
        val logEntry = LogEntry(d = today, t = System.currentTimeMillis(), k = key, v = value.toString())
        val newLog = parseLog(e.log) + logEntry
        val base = if (key == "bpm") e.copy(bpm = value, log = encodeLog(newLog))
                   else e.copy(log = encodeLog(newLog))
        edit { base }
    }

    fun lastRating(key: String): Int? =
        uiState.value.log.lastOrNull { it.k == key }?.v?.toIntOrNull()

    fun togglePin()                   = edit { it.copy(pin = !it.pin) }

    fun trash(onDone: () -> Unit)     { viewModelScope.launch { repo.trash(entryId); onDone() } }

    fun duplicate(onDone: (String) -> Unit) {
        viewModelScope.launch {
            val copy = repo.duplicate(entryId) ?: return@launch
            onDone(copy.id)
        }
    }

    // ── Champ checklist / review ─────────────────────────────────────────────

    fun checklistItems(): List<Pair<String, Boolean>> {
        val raw = uiState.value.extra["checklist"] ?: "[]"
        return runCatching {
            json.parseToJsonElement(raw).jsonArray.mapNotNull { el ->
                val o = el.jsonObject
                val text = o["t"]?.jsonPrimitive?.content
                    ?: o["text"]?.jsonPrimitive?.content
                    ?: return@mapNotNull null
                val done = o["done"]?.jsonPrimitive?.booleanOrNull
                    ?: o["d"]?.jsonPrimitive?.booleanOrNull
                    ?: false
                text to done
            }
        }.getOrElse { emptyList() }
    }

    fun toggleChecklistItem(index: Int) {
        val items = checklistItems().toMutableList()
        if (index !in items.indices) return
        val (t, d) = items[index]
        items[index] = t to !d
        saveChecklist(items)
    }

    fun addChecklistItem(text: String) {
        if (text.isBlank()) return
        saveChecklist(checklistItems() + (text.trim() to false))
    }

    fun removeChecklistItem(index: Int) {
        val items = checklistItems().toMutableList()
        if (index in items.indices) {
            items.removeAt(index)
            saveChecklist(items)
        }
    }

    private fun saveChecklist(items: List<Pair<String, Boolean>>) {
        val arr = buildJsonArray {
            items.forEach { (t, d) ->
                addJsonObject { put("t", t); put("done", d) }
            }
        }
        updateExtraField("checklist", arr.toString())
    }

    fun updateReviewField(key: String, value: String) {
        val raw = uiState.value.extra["review"] ?: "{}"
        val map = runCatching {
            json.parseToJsonElement(raw).jsonObject.toMutableMap()
        }.getOrElse { mutableMapOf() }
        // store as JsonElement strings via rebuild
        val rebuilt = buildJsonObject {
            map.forEach { (k, v) ->
                if (k != key) put(k, v)
            }
            put(key, value)
        }
        updateExtraField("review", rebuilt.toString())
    }

    fun reviewField(key: String): String {
        val raw = uiState.value.extra["review"] ?: "{}"
        return runCatching {
            json.parseToJsonElement(raw).jsonObject[key]?.jsonPrimitive?.content ?: ""
        }.getOrElse { "" }
    }


    fun loadBpmToMetronome()          { entry.value?.bpm?.let { metronome.setBpm(it) } }

    // ── Links ─────────────────────────────────────────────────────────────────

    fun showLinkPicker()              { _showLinkPicker.value = true }
    fun hideLinkPicker()              { _showLinkPicker.value = false }

    fun toggleLink(otherId: String) {
        val e = entry.value ?: return
        val links = parseJsonStringArray(e.links).toMutableList()
        if (links.contains(otherId)) links.remove(otherId) else links.add(otherId)
        edit { it.copy(links = json.encodeToString(links)) }
    }

    // ── Recording ─────────────────────────────────────────────────────────────

    fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED

    fun startRecording() {
        if (!hasMicPermission()) return
        runCatching { recorder.start() }
    }

    fun pauseRecording()  { runCatching { recorder.pause() } }
    fun resumeRecording() { runCatching { recorder.resume() } }

    /** Stop recording, save file as FileMetaEntity attached to this entry. */
    fun stopAndSaveRecording() {
        val file = runCatching { recorder.stop() }.getOrNull() ?: return
        if (!file.exists() || file.length() == 0L) return
        viewModelScope.launch {
            val duration = getAudioDurationMs(file)
            val meta = FileMetaEntity(
                id          = java.util.UUID.randomUUID().toString().replace("-", "").take(12),
                entryId     = entryId,
                name        = file.name,
                path        = file.absolutePath,
                mime        = "audio/mp4",
                size        = file.length(),
                createdAt   = System.currentTimeMillis(),
                duration    = duration,
                description = ""
            )
            repo.attachFile(meta)
        }
    }

    fun discardRecording() {
        runCatching {
            recorder.stop()?.delete()
        }
    }

    // ── File management ───────────────────────────────────────────────────────

    fun attachExternalFile(path: String, name: String, mime: String, size: Long) {
        viewModelScope.launch {
            val meta = FileMetaEntity(
                id = java.util.UUID.randomUUID().toString().replace("-", "").take(12),
                entryId = entryId, name = name, path = path,
                mime = mime, size = size,
                createdAt = System.currentTimeMillis(), duration = 0L, description = ""
            )
            repo.attachFile(meta)
        }
    }

    fun deleteFile(fileId: String) { viewModelScope.launch { repo.deleteFile(fileId) } }

    fun trimAudio(fileId: String, startMs: Long, endMs: Long, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val meta = uiState.value.files.find { it.id == fileId } ?: run {
                onDone(false); return@launch
            }
            val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.chamber.beatbox.data.audio.AudioTrimmer.trim(meta.path, startMs, endMs)
            }
            if (result == null) { onDone(false); return@launch }
            val newMeta = FileMetaEntity(
                id = java.util.UUID.randomUUID().toString().replace("-", "").take(12),
                entryId = entryId,
                name = meta.name.replace(Regex("\\.(m4a|mp4|aac)$"), "") + "_trim.m4a",
                path = result.file.absolutePath,
                mime = "audio/mp4",
                size = result.file.length(),
                duration = result.durationMs,
                description = "Trimmed ${startMs}-${endMs}ms from ${meta.name}"
            )
            repo.attachFile(newMeta)
            onDone(true)
        }
    }

    fun setPlayingFile(fileId: String?) { _playingFileId.value = fileId }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun edit(transform: (EntryEntity) -> EntryEntity) {
        val current = entry.value ?: return
        val updated = transform(current).copy(updatedAt = System.currentTimeMillis())
        viewModelScope.launch { _pendingEntry.emit(updated) }
    }

    private fun getAudioDurationMs(file: File): Long = runCatching {
        android.media.MediaMetadataRetriever().use { mmr ->
            mmr.setDataSource(file.absolutePath)
            mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        }
    }.getOrElse { 0L }

    companion object {
        fun parseExtra(extraJson: String): Map<String, String> = runCatching {
            json.parseToJsonElement(extraJson).jsonObject
                .mapValues { it.value.let { v -> if (v is JsonPrimitive) v.content else v.toString() } }
        }.getOrElse { emptyMap() }

        fun parseLog(logJson: String): List<LogEntry> = runCatching {
            json.parseToJsonElement(logJson).jsonArray.map {
                val o = it.jsonObject
                LogEntry(o["d"]?.jsonPrimitive?.content ?: "", o["t"]?.jsonPrimitive?.long ?: 0L,
                    o["k"]?.jsonPrimitive?.content ?: "", o["v"]?.jsonPrimitive?.content ?: "")
            }
        }.getOrElse { emptyList() }

        fun encodeLog(log: List<LogEntry>): String = json.encodeToString(
            log.map { buildJsonObject { put("d",it.d); put("t",it.t); put("k",it.k); put("v",it.v) } }
        )

        fun parseJsonStringArray(json2: String): List<String> = runCatching {
            json.parseToJsonElement(json2).jsonArray.mapNotNull { it.jsonPrimitive.contentOrNull }
        }.getOrElse { emptyList() }
    }
}
