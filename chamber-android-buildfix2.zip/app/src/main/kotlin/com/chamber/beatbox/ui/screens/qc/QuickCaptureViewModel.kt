package com.chamber.beatbox.ui.screens.qc

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.repository.EntryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class QuickCaptureViewModel @Inject constructor(
    private val repo: EntryRepository
) : ViewModel() {
    fun create(kind: String, name: String, onDone: (String) -> Unit) {
        viewModelScope.launch {
            val n = name.ifBlank {
                when (kind) {
                    "idea" -> "Untitled idea"
                    "oneshot" -> "Untitled 1-shot"
                    "technique" -> "Untitled technique"
                    "bars" -> "Untitled bars"
                    "champ" -> "Untitled routine"
                    "pattern" -> "Untitled pattern"
                    else -> "Untitled"
                }
            }
            val extra = if (kind == "bars") mapOf("bars" to 8) else emptyMap()
            val e = repo.newEntry(kind, n, extra)
            repo.upsert(e)
            onDone(e.id)
        }
    }
}
