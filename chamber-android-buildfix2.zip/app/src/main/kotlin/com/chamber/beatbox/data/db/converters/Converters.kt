package com.chamber.beatbox.data.db.converters

import androidx.room.TypeConverter
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

// Room doesn't store JSON natively, but since we already use kotlinx.serialization
// throughout, these converters are only needed for List<String> convenience in
// queries. All complex fields (extraJson, log, links, etc.) are stored and
// retrieved as raw strings — callers decode them in the repository layer.

internal val json = Json {
    ignoreUnknownKeys  = true
    encodeDefaults     = true
    isLenient          = true
}

class StringListConverter {
    @TypeConverter
    fun fromList(list: List<String>): String = json.encodeToString(list)

    @TypeConverter
    fun toList(value: String): List<String> = runCatching {
        json.decodeFromString<List<String>>(value)
    }.getOrElse { emptyList() }
}
