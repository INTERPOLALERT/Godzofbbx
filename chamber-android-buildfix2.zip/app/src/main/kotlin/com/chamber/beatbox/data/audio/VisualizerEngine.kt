package com.chamber.beatbox.data.audio

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.*

/**
 * Live microphone → frequency analysis engine.
 *
 * AudioRecord runs on a high-priority thread. Each read block is passed
 * through a radix-2 FFT (power-of-two window, 1024 samples). The output
 * is bucketed into [BAND_COUNT] logarithmically spaced frequency bands and
 * emitted as [VisualizerFrame] for the Compose Canvas to draw.
 *
 * Modes match the HTML visualizer exactly:
 *   SPECTRUM, PARTICLES, WAVE, RINGS, CHLADNI, GRID_BURST
 *
 * The raw waveform data and the frequency bands are both available in
 * every frame so each mode can choose what it needs.
 *
 * Permission: caller must hold RECORD_AUDIO before calling [start].
 */
class VisualizerEngine {

    /** Visualization mode — names match the HTML's VIZ.modes array. */
    enum class Mode(val label: String) {
        SPECTRUM   ("SPECTRUM"),
        PARTICLES  ("PARTICLES"),
        WAVE       ("WAVE"),
        RINGS      ("RINGS"),
        CHLADNI    ("CHLADNI"),
        GRID_BURST ("GRID BURST")
    }

    /**
     * A single analysis frame emitted each audio callback.
     *
     * @param bands    Normalized amplitude 0f–1f per frequency band
     * @param wave     Raw PCM samples normalized to -1f..1f (1024 samples)
     * @param energy   Overall signal energy 0f–1f
     * @param peakBin  Index of dominant frequency bin
     * @param time     Monotonic frame counter (use for particle animation)
     */
    data class VisualizerFrame(
        val bands: FloatArray,
        val wave: FloatArray,
        val energy: Float,
        val peakBin: Int,
        val time: Long
    )

    companion object {
        const val BAND_COUNT    = 64      // frequency bands (matches HTML's nF/4 usable range)
        const val FFT_SIZE      = 1024    // must be power of two
        const val SAMPLE_RATE   = 44100
        const val SMOOTHING     = 0.75f   // exponential smoothing (HTML uses 0.75)
    }

    var mode: Mode = Mode.SPECTRUM

    private val _frames = MutableSharedFlow<VisualizerFrame>(
        replay = 0, extraBufferCapacity = 2,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )
    val frames: SharedFlow<VisualizerFrame> = _frames.asSharedFlow()

    private val _running = kotlinx.coroutines.flow.MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _running.asStateFlow()

    private var readerJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private val engineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val smoothedBands = FloatArray(BAND_COUNT)
    private var frameIndex = 0L

    fun start() {
        if (_running.value) return
        val bufSize = maxOf(
            AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_FLOAT),
            FFT_SIZE * 4
        )
        val record = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_FLOAT,
            bufSize
        )
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return
        }
        audioRecord = record
        _running.value = true

        readerJob = engineScope.launch {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            record.startRecording()
            val pcm = FloatArray(FFT_SIZE)
            try {
                while (isActive && _running.value) {
                    val read = record.read(pcm, 0, FFT_SIZE, AudioRecord.READ_BLOCKING)
                    if (read <= 0) continue
                    processFrame(pcm, read)
                }
            } finally {
                record.stop()
                record.release()
            }
        }
    }

    fun stop() {
        _running.value = false
        readerJob?.cancel()
        readerJob = null
        audioRecord = null
        smoothedBands.fill(0f)
    }

    fun release() {
        stop()
        engineScope.cancel()
    }

    private fun processFrame(pcm: FloatArray, validSamples: Int) {
        // Apply Hanning window to reduce spectral leakage
        val windowed = FloatArray(FFT_SIZE)
        for (i in 0 until validSamples) {
            val w = 0.5f * (1f - cos(2f * PI.toFloat() * i / (FFT_SIZE - 1)))
            windowed[i] = pcm[i] * w
        }

        // In-place radix-2 FFT (real input → complex output interleaved)
        val fftOut = FloatArray(FFT_SIZE * 2)
        for (i in 0 until FFT_SIZE) {
            fftOut[2 * i]     = windowed[i]
            fftOut[2 * i + 1] = 0f
        }
        fft(fftOut, FFT_SIZE)

        // Magnitude spectrum (only first half is meaningful for real input)
        val binCount = FFT_SIZE / 2
        val magnitude = FloatArray(binCount)
        var maxMag = 0f
        var peakBin = 1
        for (i in 1 until binCount) {
            val re = fftOut[2 * i]
            val im = fftOut[2 * i + 1]
            val mag = sqrt(re * re + im * im)
            magnitude[i] = mag
            if (mag > maxMag) { maxMag = mag; peakBin = i }
        }

        // Map bins → log-spaced bands
        val bands = FloatArray(BAND_COUNT)
        val freqMin = 20.0
        val freqMax = (SAMPLE_RATE / 2).toDouble()
        val logMin = log10(freqMin)
        val logMax = log10(freqMax)
        for (b in 0 until BAND_COUNT) {
            val freqLow  = 10.0.pow(logMin + (b.toDouble() / BAND_COUNT) * (logMax - logMin))
            val freqHigh = 10.0.pow(logMin + ((b + 1).toDouble() / BAND_COUNT) * (logMax - logMin))
            val binLow  = (freqLow  / freqMax * binCount).toInt().coerceIn(0, binCount - 1)
            val binHigh = (freqHigh / freqMax * binCount).toInt().coerceIn(0, binCount - 1)
            var sum = 0f
            var count = 0
            for (i in binLow..binHigh) { sum += magnitude[i]; count++ }
            bands[b] = if (count > 0) sum / count else 0f
        }

        // Normalize bands to 0–1
        val bandMax = bands.max().coerceAtLeast(1f)
        for (b in 0 until BAND_COUNT) bands[b] /= bandMax

        // Exponential smoothing (HTML: smoothingTimeConstant = 0.75)
        for (b in 0 until BAND_COUNT) {
            smoothedBands[b] = SMOOTHING * smoothedBands[b] + (1f - SMOOTHING) * bands[b]
        }

        // Energy: mean of all bands
        val energy = smoothedBands.average().toFloat()

        // Normalize waveform to -1..1 for WAVE mode
        val wave = FloatArray(minOf(validSamples, FFT_SIZE)) { i -> pcm[i].coerceIn(-1f, 1f) }

        val frame = VisualizerFrame(
            bands   = smoothedBands.copyOf(),
            wave    = wave,
            energy  = energy,
            peakBin = peakBin,
            time    = frameIndex++
        )
        _frames.tryEmit(frame)
    }

    // ── Cooley-Tukey radix-2 FFT (in-place, complex interleaved) ─────────────
    //
    // Input/output: [re0, im0, re1, im1, ..., re(n-1), im(n-1)]
    // n must be a power of two.

    private fun fft(x: FloatArray, n: Int) {
        // Bit-reversal permutation
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                var tmp = x[2 * i];    x[2 * i]     = x[2 * j];     x[2 * j]     = tmp
                tmp     = x[2 * i + 1]; x[2 * i + 1] = x[2 * j + 1]; x[2 * j + 1] = tmp
            }
        }
        // Butterfly stages
        var len = 2
        while (len <= n) {
            val halfLen = len / 2
            val angle = (-2.0 * PI / len).toFloat()
            val wRe = cos(angle.toDouble()).toFloat()
            val wIm = sin(angle.toDouble()).toFloat()
            var i = 0
            while (i < n) {
                var curRe = 1f; var curIm = 0f
                for (k in 0 until halfLen) {
                    val uRe = x[2 * (i + k)]
                    val uIm = x[2 * (i + k) + 1]
                    val vRe = x[2 * (i + k + halfLen)]     * curRe - x[2 * (i + k + halfLen) + 1] * curIm
                    val vIm = x[2 * (i + k + halfLen) + 1] * curRe + x[2 * (i + k + halfLen)]     * curIm
                    x[2 * (i + k)]              = uRe + vRe
                    x[2 * (i + k) + 1]          = uIm + vIm
                    x[2 * (i + k + halfLen)]     = uRe - vRe
                    x[2 * (i + k + halfLen) + 1] = uIm - vIm
                    val newRe = curRe * wRe - curIm * wIm
                    curIm = curRe * wIm + curIm * wRe
                    curRe = newRe
                }
                i += len
            }
            len *= 2
        }
    }
}
