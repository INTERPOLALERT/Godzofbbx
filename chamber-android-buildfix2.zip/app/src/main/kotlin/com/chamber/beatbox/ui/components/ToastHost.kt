
package com.chamber.beatbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.chamber.beatbox.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/** App-wide toast matching HTML toast() — 2.6s black bar. */
object ChamberToast {
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events = _events.asSharedFlow()
    fun show(msg: String) { _events.tryEmit(msg) }
}

@Composable
fun ToastHost(modifier: Modifier = Modifier) {
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        ChamberToast.events.collect { msg ->
            message = msg
        }
    }
    LaunchedEffect(message) {
        if (message != null) {
            delay(2600)
            message = null
        }
    }
    message?.let { msg ->
        Box(
            modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 80.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Text(
                msg.uppercase(),
                style = ChamberType.MonoLabel,
                color = Bg,
                modifier = Modifier
                    .background(Ink)
                    .border(2.dp, Ink)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            )
        }
    }
}
