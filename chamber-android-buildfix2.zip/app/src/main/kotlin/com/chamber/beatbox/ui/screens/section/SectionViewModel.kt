package com.chamber.beatbox.ui.screens.section

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.ui.navigation.Routes
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel(assistedFactory = SectionViewModel.Factory::class)
class SectionViewModel @AssistedInject constructor(
    private val repo: EntryRepository,
    @Assisted private val sectionId: String
) : ViewModel() {

    @AssistedFactory
    interface Factory {
        fun create(sectionId: String): SectionViewModel
    }

    private val sec = Routes.sectionById[sectionId]

    val entries: StateFlow<List<EntryEntity>> = when {
        sec == null                 -> emptyFlow()
        sec.kind == "technique" && sec.cat != null ->
            repo.observeTechniquesByCat(sec.cat)
        sec.kind == "bars" && sec.bars != null ->
            repo.observeBarsByCount(sec.bars)
        sec.kind != null            ->
            repo.observeByKind(sec.kind)
        else                        -> emptyFlow()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun createEntry(nav: NavHostController) {
        val sec = sec ?: return
        if (sec.kind == null) return
        viewModelScope.launch {
            val name = "New ${sec.title.removeSuffix("s")}"  // TODO: show input dialog
            val extra = buildMap<String, Any?> {
                sec.bars?.let { put("bars", it) }
                sec.cat?.let { put("cat", it) }
            }
            val entry = repo.newEntry(sec.kind, name, extra)
            repo.upsert(entry)
            nav.navigate(Routes.entry(entry.id))
        }
    }

    private fun <T> emptyFlow() = kotlinx.coroutines.flow.flowOf<List<T>>(emptyList())
}
