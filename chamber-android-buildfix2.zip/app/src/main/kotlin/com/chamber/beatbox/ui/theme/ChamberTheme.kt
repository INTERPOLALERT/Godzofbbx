package com.chamber.beatbox.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chamber.beatbox.R

// ── Colors ────────────────────────────────────────────────────────────────────
// Strict black/white — no Material surface tints, no elevation overlays.

val Ink   = Color(0xFF000000)
val Bg    = Color(0xFFFFFFFF)
val Muted = Color(0xFF555555)
val Red   = Color(0xFFCC0000)

// For dark-surface views (Trainer, Battle, Visualizer)
val InkOnDark   = Color(0xFFFFFFFF)
val BgDark      = Color(0xFF000000)
val MutedOnDark = Color(0xFF9A9A9A)

private val LightColors = lightColorScheme(
    primary          = Ink,
    onPrimary        = Bg,
    secondary        = Ink,
    onSecondary      = Bg,
    background       = Bg,
    onBackground     = Ink,
    surface          = Bg,
    onSurface        = Ink,
    error            = Red,
    onError          = Bg,
    outline          = Ink,
    surfaceVariant   = Bg,
    onSurfaceVariant = Muted
)

// CHAMBER uses a dark surface for certain full-screen views (trainer, battle).
// Those views opt in by using a dark container, not by switching the entire theme.
private val DarkColors = darkColorScheme(
    primary          = InkOnDark,
    onPrimary        = BgDark,
    secondary        = InkOnDark,
    onSecondary      = BgDark,
    background       = BgDark,
    onBackground     = InkOnDark,
    surface          = BgDark,
    onSurface        = InkOnDark,
    error            = Red,
    onError          = BgDark,
    outline          = InkOnDark,
    surfaceVariant   = BgDark,
    onSurfaceVariant = MutedOnDark
)

// ── Typography ─────────────────────────────────────────────────────────────────
// Anton = Impact equivalent from Google Fonts (free, closest match).
// JetBrains Mono = the monospace used for metadata/counts.
// System sans-serif for body text.

private val provider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage   = "com.google.android.gms",
    certificates      = R.array.com_google_android_gms_fonts_certs
)

val AntonFamily: FontFamily = FontFamily(
    Font(GoogleFont("Anton"), provider)
)

val JetBrainsMonoFamily: FontFamily = FontFamily(
    Font(GoogleFont("JetBrains Mono"), provider, weight = FontWeight.Normal),
    Font(GoogleFont("JetBrains Mono"), provider, weight = FontWeight.Bold)
)

// Named text styles to use in Composables
object ChamberType {
    /** 72px Impact-style — section glyph / huge number */
    val Glyph = TextStyle(fontFamily = AntonFamily, fontSize = 72.sp, fontWeight = FontWeight.Normal, lineHeight = 54.sp)

    /** 30px Impact-style — section/entry title (h1) */
    val Title = TextStyle(fontFamily = AntonFamily, fontSize = 30.sp, letterSpacing = 0.5.sp)

    /** 24px Impact-style — brand header, entry name display */
    val Brand = TextStyle(fontFamily = AntonFamily, fontSize = 24.sp, letterSpacing = 1.sp)

    /** 20px Impact-style — section lines (secline) */
    val SectionLine = TextStyle(fontFamily = AntonFamily, fontSize = 20.sp, letterSpacing = 0.5.sp)

    /** 74px — big clock readout */
    val ClockLarge = TextStyle(fontFamily = AntonFamily, fontSize = 74.sp, letterSpacing = 2.sp)

    /** 44px — smaller clock (sm) */
    val ClockSmall = TextStyle(fontFamily = AntonFamily, fontSize = 44.sp, letterSpacing = 1.sp)

    /** 36px — BPM display in metronome */
    val Bpm = TextStyle(fontFamily = AntonFamily, fontSize = 36.sp, lineHeight = 36.sp)

    /** 34px — tile big number */
    val TileBig = TextStyle(fontFamily = AntonFamily, fontSize = 34.sp, lineHeight = 32.sp)

    /** Body — 16px system sans-serif */
    val Body = TextStyle(fontSize = 16.sp, lineHeight = (16 * 1.45).sp)

    /** Bold body label — 16px, weight 800 */
    val BodyBold = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)

    /** Monospace metadata — 12px */
    val Mono = TextStyle(fontFamily = JetBrainsMonoFamily, fontSize = 12.sp)

    /** Monospace tiny — 10px for strip counts, tile labels */
    val MonoTiny = TextStyle(fontFamily = JetBrainsMonoFamily, fontSize = 10.sp, letterSpacing = 1.sp)

    /** Monospace label — 11px, uppercase, letter-spacing */
    val MonoLabel = TextStyle(fontFamily = JetBrainsMonoFamily, fontSize = 11.sp,
        letterSpacing = 1.5.sp, fontWeight = FontWeight.ExtraBold)

    /** Field label — 11px, uppercase */
    val FieldLabel = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)

    /** Button text — 15px, weight 800, uppercase */
    val Button = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)

    /** Big button — 18px */
    val ButtonBig = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp)

    /** Small button — 13px */
    val ButtonSm = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
}

// ── Dimensions ──────────────────────────────────────────────────────────────
object ChamberDimens {
    val BorderWidth: Dp  = 2.dp
    val BorderThick: Dp  = 3.dp  // section heads, overlays
    val TopBarHeight: Dp = 52.dp
    val StripHeight: Dp  = 52.dp  // chip strip
    val FabSize: Dp      = 52.dp
    val MinTouchTarget: Dp = 44.dp

    // Spacing
    val ContentPaddingH: Dp = 14.dp
    val ContentPaddingV: Dp = 16.dp

    // Bottom padding so content isn't hidden behind FAB + strip
    val BottomPadding: Dp = 130.dp

    // Dot size for metronome beat indicator
    val BeatDotNormal: Dp = 16.dp
    val BeatDotAccent: Dp = 20.dp
}

// ── Shapes — everything is RectangleShape (zero corner radius) ───────────────
val ChamberShapes = Shapes(
    extraSmall = RectangleShape,
    small      = RectangleShape,
    medium     = RectangleShape,
    large      = RectangleShape,
    extraLarge = RectangleShape
)

// ── CompositionLocal for dark-surface views ───────────────────────────────────
data class ChamberColors(
    val ink:        Color,
    val bg:         Color,
    val muted:      Color,
    val red:        Color = Red,
    val isDark:     Boolean
)

val LocalChamberColors = staticCompositionLocalOf {
    ChamberColors(ink = Ink, bg = Bg, muted = Muted, isDark = false)
}

@Composable
fun ChamberTheme(
    darkSurface: Boolean = false,
    content: @Composable () -> Unit
) {
    val chamberColors = if (darkSurface) {
        ChamberColors(ink = InkOnDark, bg = BgDark, muted = MutedOnDark, isDark = true)
    } else {
        ChamberColors(ink = Ink, bg = Bg, muted = Muted, isDark = false)
    }

    val m3Colors = if (darkSurface) DarkColors else LightColors

    CompositionLocalProvider(LocalChamberColors provides chamberColors) {
        MaterialTheme(
            colorScheme = m3Colors,
            shapes      = ChamberShapes,
            content     = content
        )
    }
}
