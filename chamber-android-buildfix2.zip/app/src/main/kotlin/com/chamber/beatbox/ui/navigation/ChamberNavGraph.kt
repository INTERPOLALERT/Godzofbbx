package com.chamber.beatbox.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.chamber.beatbox.ui.screens.data.DataScreen
import com.chamber.beatbox.ui.screens.entry.EntryScreen
import com.chamber.beatbox.ui.screens.home.HomeScreen
import com.chamber.beatbox.ui.screens.search.SearchScreen
import com.chamber.beatbox.ui.screens.pattern.PatternScreen
import com.chamber.beatbox.ui.screens.quests.QuestsScreen
import com.chamber.beatbox.ui.screens.section.SectionScreen
import com.chamber.beatbox.ui.screens.stats.StatsScreen
import com.chamber.beatbox.ui.screens.trainer.TrainerScreen
import com.chamber.beatbox.ui.screens.visualizer.VisualizerScreen
import com.chamber.beatbox.ui.screens.godmode.GodmodeScreen

@Composable
fun ChamberNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController  = navController,
        startDestination = Routes.HOME,
        modifier       = modifier
    ) {
        // ── Home ──────────────────────────────────────────────────────────────
        composable(Routes.HOME) {
            HomeScreen(nav = navController)
        }

        // ── Custom page screens ───────────────────────────────────────────────
        composable(Routes.TRAINER)  { TrainerScreen(nav = navController) }
        composable(Routes.DRILL)    { TrainerScreen(nav = navController, initialTab = "drill") }
        composable(Routes.BATTLE)   { TrainerScreen(nav = navController, initialTab = "battle") }
        composable(Routes.VIZ)      { VisualizerScreen(nav = navController) }
        composable(Routes.QUESTS)   { QuestsScreen(nav = navController) }
        composable(Routes.STATS)    { StatsScreen(nav = navController) }
        composable(Routes.DATA)     { DataScreen(nav = navController) }
        composable(Routes.SEARCH)   { SearchScreen(nav = navController) }

        // GODMODE — force-directed map + coach
        composable(Routes.GODMODE) {
            GodmodeScreen(nav = navController)
        }

        // ── Pattern Lab ───────────────────────────────────────────────────────
        composable(Routes.PATTERN) { PatternScreen(navController) }

        // ── All list-backed sections ──────────────────────────────────────────
        // Sections that are backed by entry lists all share one screen parameterised
        // by section ID. The screen reads section info from Routes.sectionById.
        listOf(
            Routes.CHAMP, Routes.IDEAS,
            Routes.BARS4, Routes.BARS8, Routes.BARS16, Routes.BARS32, Routes.BARS64,
            Routes.ONESHOT, Routes.SETLIST,
            Routes.MUSICALITY, Routes.TECHNIQUE, Routes.TONGUEBASS, Routes.SFX, Routes.SINGING,
            Routes.SOCIAL, Routes.VOCODE, Routes.GENRES, Routes.PRACTICE, Routes.GOALS
        ).forEach { route ->
            val sectionId = route.removePrefix("s/")
            composable(route) {
                SectionScreen(sectionId = sectionId, nav = navController)
            }
        }

        // ── Entry detail / editor ─────────────────────────────────────────────
        composable(
            route     = Routes.ENTRY,
            arguments = listOf(navArgument(Routes.ENTRY_ARG) { type = NavType.StringType })
        ) { back ->
            val entryId = back.arguments?.getString(Routes.ENTRY_ARG) ?: return@composable
            EntryScreen(entryId = entryId, nav = navController)
        }
    }
}

