package com.chamber.beatbox.ui.screens.pattern

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.db.entities.EntryEntity
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PatternListViewModel @Inject constructor(private val repo: EntryRepository) : ViewModel() {
    val patterns: StateFlow<List<EntryEntity>> = repo.observeByKind("pattern")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun newPattern(name: String, nav: NavHostController) {
        viewModelScope.launch {
            val entry = repo.newEntry("pattern", name.ifBlank { "Pattern ${System.currentTimeMillis() % 10000}" })
            repo.upsert(entry)
            nav.navigate(Routes.entry(entry.id))
        }
    }

    fun newFromPreset(presetName: String, bpm: Int, nav: NavHostController) {
        viewModelScope.launch {
            val entry = repo.newEntry("pattern", presetName, mapOf("bpm" to bpm.toString()))
            // Apply a simple preset grid via extraJson after creation if needed
            repo.upsert(entry.copy(bpm = bpm))
            nav.navigate(Routes.entry(entry.id))
        }
    }
}

@Composable
fun PatternScreen(nav: NavHostController, vm: PatternListViewModel = hiltViewModel()) {
    val patterns by vm.patterns.collectAsStateWithLifecycle()
    val c = LocalChamberColors.current
    var newName by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(ChamberDimens.ContentPaddingH)) {
        item {
            Spacer(Modifier.height(ChamberDimens.ContentPaddingV))
            SectionHead("▦", "Pattern Lab", "STEP SEQUENCER · SWING · GROOVES")
            Spacer(Modifier.height(12.dp))
            HintBox("Each pattern entry has a 16-step sequencer. Tap a pattern to open the grid.")
            Spacer(Modifier.height(12.dp))
        }

        item {
            SectionLine("Presets")
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    Triple("Basic 4/4", 100, "basic"),
                    Triple("Hip-Hop", 90, "hiphop"),
                    Triple("D&B", 174, "dnb")
                ).forEach { (name, bpm, _) ->
                    ChamberButton(name, onClick = { vm.newFromPreset(name, bpm, nav) }, size = ButtonSize.Small, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    Triple("Garage", 130, "garage"),
                    Triple("Triplet", 140, "triplet")
                ).forEach { (name, bpm, _) ->
                    ChamberButton(name, onClick = { vm.newFromPreset(name, bpm, nav) }, size = ButtonSize.Small, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(12.dp))
        }


        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ChamberField(newName, { newName = it }, placeholder = "New pattern name…", modifier = Modifier.weight(1f))
                ChamberButton("+ NEW", size = ButtonSize.Small,
                    onClick = { vm.newPattern(newName, nav); newName = "" })
            }
            Spacer(Modifier.height(8.dp))
            SectionLine("Patterns", count = patterns.size)
        }

        if (patterns.isEmpty()) {
            item {
                HintBox("No patterns yet. Create one above.")
                Spacer(Modifier.height(8.dp))
            }
        }

        items(patterns, key = { it.id }) { p ->
            ChamberRow(
                name     = p.name.ifBlank { "Untitled Pattern" },
                meta     = buildString {
                    p.bpm?.let { append("$it BPM · ") }
                    append("updated ${ago(p.updatedAt)}")
                },
                glyph    = "▦",
                modifier = Modifier.clickable { nav.navigate(Routes.entry(p.id)) }
            )
        }
        item { Spacer(Modifier.height(ChamberDimens.BottomPadding)) }
    }
}

private fun ago(t: Long): String {
    val s = (System.currentTimeMillis() - t) / 1000
    return when { s < 3600 -> "${s/60}m"; s < 86400 -> "${s/3600}h"; else -> "${s/86400}d" }
}
