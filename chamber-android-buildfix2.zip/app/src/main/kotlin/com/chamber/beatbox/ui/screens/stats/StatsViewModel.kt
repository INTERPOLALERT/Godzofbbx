package com.chamber.beatbox.ui.screens.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.chamber.beatbox.data.db.entities.HealthLogEntity
import com.chamber.beatbox.data.drill.DrillBuilder
import com.chamber.beatbox.data.repository.EntryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class StatsUiState(
    val bpmCoverage: List<Pair<String, Boolean>> = emptyList(),
    val streak: Int = 0,
    val totalMinutes: Int = 0,
    val sessionCount: Int = 0,
    val entryCount: Int = 0,
    val avgDailyThisWeek: Int = 0,
    val avgDailyAllTime: Int = 0,
    val weeklyBars: List<Pair<String, Int>> = emptyList(),
    val techniqueCounts: Map<String, Int> = emptyMap(),
    val recentStrain: List<Pair<String, Int>> = emptyList(),
    val focusTags: List<Pair<String, Int>> = emptyList()
)

@HiltViewModel
class StatsViewModel @Inject constructor(private val repo: EntryRepository) : ViewModel() {

    private val _refresh = MutableStateFlow(0)
    val uiState: StateFlow<StatsUiState> = _refresh
        .map { buildState() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUiState())

    init {
        viewModelScope.launch {
            repo.observeRecentSessions().collect { _refresh.value = _refresh.value + 1 }
        }
    }

    fun refresh() { _refresh.value = _refresh.value + 1 }

    /** Log vocal strain 1–5 after a session. */
    fun logStrain(strain: Int, minutes: Int = 0) {
        viewModelScope.launch {
            repo.logHealth(HealthLogEntity(
                day = LocalDate.now().toString(),
                strain = strain.coerceIn(1, 5),
                minutes = minutes
            ))
            refresh()
        }
    }

    private suspend fun buildState(): StatsUiState {
        val allDays    = repo.allPracticeDays().toSet()
        val streak     = computeStreak(allDays)
        val totalMins  = repo.totalPracticeMinutes()
        val sessions   = repo.observeRecentSessions(200).first()
        val entries    = repo.observeAll().first()

        val eightWeeksAgo = LocalDate.now().minusWeeks(8).toString()
        val dailyMins = repo.dailyMinutesSince(eightWeeksAgo)
        val today = LocalDate.now()
        val weeklyBars = (55 downTo 0).map { daysBack ->
            val day = today.minusDays(daysBack.toLong()).toString()
            day.takeLast(5) to (dailyMins.find { it.day == day }?.minutes ?: 0)
        }

        val mondayStr = LocalDate.now().with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY)).toString()
        val weekMins = dailyMins.filter { it.day >= mondayStr }.sumOf { it.minutes }
        val weekDays = dailyMins.count { it.day >= mondayStr }.coerceAtLeast(1)
        val activeDays = allDays.size.coerceAtLeast(1)

        val rawCounts  = repo.techniqueCatCounts()
        val totalTech  = repo.countByKind("technique")
        val techCounts = mapOf(
            "technique"  to totalTech,
            "musicality" to (rawCounts["musicality"] ?: 0),
            "tonguebass" to (rawCounts["tonguebass"] ?: 0),
            "sfx"        to (rawCounts["sfx"] ?: 0),
            "singing"    to (rawCounts["singing"] ?: 0)
        )

        val strain = repo.observeRecentHealth(14).first().map { it.day to it.strain }

        val focusFreq = sessions
            .filter { it.focus.isNotBlank() }
            .groupBy { it.focus.trim() }
            .mapValues { it.value.size }
            .entries.sortedByDescending { it.value }
            .map { it.key to it.value }

        // BPM coverage bands
        val usedBpms = entries.mapNotNull { it.bpm }.toSet()
        val bands = listOf(
            "Under 90" to (60..89),
            "90–119" to (90..119),
            "120–139" to (120..139),
            "140–159" to (140..159),
            "160–179" to (160..179),
            "180+" to (180..240)
        )
        val bpmCoverage = bands.map { (label, range) ->
            label to usedBpms.any { it in range }
        }

        return StatsUiState(
            bpmCoverage      = bpmCoverage,
            streak           = streak,
            totalMinutes     = totalMins,
            sessionCount     = sessions.size,
            entryCount       = entries.size,
            avgDailyThisWeek = if (weekDays > 0) weekMins / weekDays else 0,
            avgDailyAllTime  = totalMins / activeDays,
            weeklyBars       = weeklyBars,
            techniqueCounts  = techCounts,
            recentStrain     = strain,
            focusTags        = focusFreq
        )
    }

    private fun computeStreak(days: Set<String>): Int {
        var streak = 0; var check = LocalDate.now()
        while (days.contains(check.toString())) { streak++; check = check.minusDays(1) }
        return streak
    }
}
