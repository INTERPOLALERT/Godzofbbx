package com.chamber.beatbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.chamber.beatbox.ui.theme.*
import androidx.compose.foundation.interaction.collectIsPressedAsState

// ── Helpers ─────────────────────────────────────────────────────────────────

@Composable
fun chamberColors() = LocalChamberColors.current

/** Active press state: swaps ink and bg, matching CSS .btn:active. */
@Composable
fun invertedBackground(pressed: Boolean, ink: Color, bg: Color): Modifier =
    if (pressed) Modifier.background(ink) else Modifier.background(bg)

// ── ChamberButton ─────────────────────────────────────────────────────────────
// Matches .btn CSS class: 2px border, uppercase, weight 800, min 48px height.

enum class ButtonSize { Normal, Big, Small, ExtraSmall }
enum class ButtonStyle { Normal, Danger }

@Composable
fun ChamberButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: ButtonSize   = ButtonSize.Normal,
    style: ButtonStyle = ButtonStyle.Normal,
    enabled: Boolean   = true,
    leading: String?   = null
) {
    val c = chamberColors()
    val borderColor = if (style == ButtonStyle.Danger) Red else c.ink
    val textColor   = if (style == ButtonStyle.Danger) Red else c.ink

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val bgColor    = if (isPressed) (if (style == ButtonStyle.Danger) Red else c.ink) else c.bg
    val fgColor    = if (isPressed) c.bg else textColor

    val minHeight = when (size) {
        ButtonSize.Big       -> 58.dp
        ButtonSize.Normal    -> 48.dp
        ButtonSize.Small     -> 38.dp
        ButtonSize.ExtraSmall -> 32.dp
    }
    val textStyle = when (size) {
        ButtonSize.Big        -> ChamberType.ButtonBig
        ButtonSize.Normal     -> ChamberType.Button
        ButtonSize.Small, ButtonSize.ExtraSmall -> ChamberType.ButtonSm
    }
    val hPad = when (size) {
        ButtonSize.Big     -> 16.dp
        ButtonSize.Normal  -> 16.dp
        ButtonSize.Small   -> 10.dp
        ButtonSize.ExtraSmall -> 8.dp
    }
    val vPad = when (size) {
        ButtonSize.Big     -> 10.dp
        ButtonSize.Normal  -> 10.dp
        ButtonSize.Small   -> 6.dp
        ButtonSize.ExtraSmall -> 4.dp
    }

    Row(
        modifier = modifier
            .border(ChamberDimens.BorderWidth, borderColor)
            .background(bgColor)
            .clickable(
                interactionSource = interactionSource,
                indication        = null,
                enabled           = enabled,
                onClick           = onClick
            )
            .defaultMinSize(minHeight = minHeight)
            .padding(horizontal = hPad, vertical = vPad),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment     = Alignment.CenterVertically
    ) {
        if (leading != null) {
            Text(leading, style = textStyle, color = fgColor)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            label.uppercase(),
            style    = textStyle,
            color    = fgColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ── ChamberRow ────────────────────────────────────────────────────────────────
// Matches .row CSS: full-width, 2px border, name + metadata, press inverts.

@Composable
fun ChamberRow(
    name: String,
    meta: String? = null,
    glyph: String? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val c = chamberColors()
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val bgColor = if (isPressed) c.ink else c.bg
    val fgColor = if (isPressed) c.bg else c.ink
    val muteColor = if (isPressed) c.bg.copy(alpha = 0.85f) else c.muted

    Row(
        modifier = modifier
            .fillMaxWidth()
            .border(ChamberDimens.BorderWidth, c.ink)
            .background(bgColor)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph != null) {
            Text(glyph, style = ChamberType.MonoLabel, color = muteColor,
                modifier = Modifier.padding(end = 8.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(name, style = ChamberType.BodyBold, color = fgColor,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (meta != null) {
                Text(meta.uppercase(), style = ChamberType.Mono, color = muteColor,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

// ── SectionLine ───────────────────────────────────────────────────────────────
// Matches .secline: Impact font, uppercase, bottom border, optional count badge.

@Composable
fun SectionLine(
    title: String,
    count: Int? = null,
    modifier: Modifier = Modifier
) {
    val c = chamberColors()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 26.dp, bottom = 0.dp)
            .drawBehind {
                val y = size.height - 2f
                drawLine(c.ink, Offset(0f, y), Offset(size.width, y), strokeWidth = 4f)
            }
            .padding(bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title.uppercase(),
            style = ChamberType.SectionLine,
            color = c.ink,
            modifier = Modifier.weight(1f)
        )
        if (count != null) {
            Text(count.toString(), style = ChamberType.Mono, color = c.muted,
                modifier = Modifier.padding(start = 8.dp))
        }
    }
}

// ── SectionHead ───────────────────────────────────────────────────────────────
// Matches .head: glyph + title + subtitle, thick bottom border.

@Composable
fun SectionHead(
    glyph: String,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    val c = chamberColors()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind {
                val y = size.height - 3f
                drawLine(c.ink, Offset(0f, y), Offset(size.width, y), strokeWidth = 6f)
            }
            .padding(bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(glyph, style = ChamberType.Glyph, color = c.ink,
            modifier = Modifier.padding(end = 14.dp))
        Column {
            Text(title.uppercase(), style = ChamberType.Title, color = c.ink)
            Text(subtitle.uppercase(), style = ChamberType.Mono, color = c.muted,
                modifier = Modifier.padding(top = 2.dp))
        }
    }
}

// ── HintBox ───────────────────────────────────────────────────────────────────
// Matches .hint: dashed border, mono font.

@Composable
fun HintBox(text: String, modifier: Modifier = Modifier) {
    val c = chamberColors()
    // Dashed border via drawBehind for exact match to CSS dashed
    Text(
        text,
        style    = ChamberType.Mono,
        color    = c.muted,
        modifier = modifier
            .fillMaxWidth()
            .border(ChamberDimens.BorderWidth, c.ink) // TODO: make dashed
            .padding(10.dp)
    )
}

// ── ProgressBar ───────────────────────────────────────────────────────────────
// Matches .bar + .barlbl

@Composable
fun ChamberProgressBar(
    label: String,
    value: Number,
    max: Number,
    suffix: String = "",
    modifier: Modifier = Modifier
) {
    val c = chamberColors()
    val fraction = (value.toFloat() / max.toFloat().coerceAtLeast(0.001f)).coerceIn(0f, 1f)
    Column(modifier = modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = ChamberType.Mono, color = c.muted)
            Text("$value$suffix", style = ChamberType.Mono, color = c.muted)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(18.dp)
                .border(ChamberDimens.BorderWidth, c.ink)
                .background(c.bg)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxHeight()
                    .background(c.ink)
            )
        }
    }
}

// ── ChamberField ─────────────────────────────────────────────────────────────
// Matches input/textarea CSS: 2px border, 46px min height.

@Composable
fun ChamberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String? = null,
    placeholder: String = "",
    modifier: Modifier = Modifier,
    multiline: Boolean = false,
    textStyle: TextStyle = ChamberType.Body
) {
    val c = chamberColors()
    Column(modifier = modifier) {
        if (label != null) {
            Text(
                label.uppercase(),
                style    = ChamberType.FieldLabel,
                color    = c.muted,
                modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
            )
        }
        BasicTextField(
            value           = value,
            onValueChange   = onValueChange,
            textStyle       = textStyle.copy(color = c.ink),
            cursorBrush     = SolidColor(c.ink),
            singleLine      = !multiline,
            decorationBox   = { inner ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(ChamberDimens.BorderWidth, c.ink)
                        .background(c.bg)
                        .defaultMinSize(minHeight = if (multiline) 84.dp else 46.dp)
                        .padding(10.dp)
                ) {
                    if (value.isEmpty()) {
                        Text(placeholder, style = textStyle.copy(color = Color(0xFF999999)))
                    }
                    inner()
                }
            }
        )
    }
}

// ── StatTile ─────────────────────────────────────────────────────────────────
// Matches .tile: big number + label, 2px border.

@Composable
fun StatTile(
    big: String,
    label: String,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val c = chamberColors()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val bg = if (pressed) c.ink else c.bg
    val fg = if (pressed) c.bg else c.ink
    val muted = if (pressed) c.bg.copy(alpha = 0.85f) else c.muted
    Column(
        modifier = modifier
            .border(ChamberDimens.BorderWidth, c.ink)
            .background(bg)
            .then(
                if (onClick != null)
                    Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick)
                else Modifier
            )
            .padding(10.dp)
            .defaultMinSize(minWidth = 80.dp)
    ) {
        Text(big, style = ChamberType.TileBig, color = fg)
        Text(label.uppercase(), style = ChamberType.MonoTiny, color = muted,
            modifier = Modifier.padding(top = 3.dp))
    }
}

// ── ClockDisplay ─────────────────────────────────────────────────────────────
// Matches .clock: Impact, 74px, border, optional alert state.

@Composable
fun ClockDisplay(
    time: String,
    small: Boolean = false,
    alert: Boolean = false,
    modifier: Modifier = Modifier
) {
    val c = chamberColors()
    val bgColor = if (alert) Red else c.bg
    val fgColor = if (alert) Color.White else c.ink

    Box(
        modifier = modifier
            .fillMaxWidth()
            .border(if (alert) ChamberDimens.BorderThick else ChamberDimens.BorderWidth,
                if (alert) Red else c.ink)
            .background(bgColor)
            .padding(if (small) 8.dp else 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            time,
            style = if (small) ChamberType.ClockSmall else ChamberType.ClockLarge,
            color = fgColor
        )
    }
}
