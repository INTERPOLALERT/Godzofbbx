package com.chamber.beatbox.data.db.dao

import androidx.room.*
import com.chamber.beatbox.data.db.entities.*
import kotlinx.coroutines.flow.Flow

// ============================================================
// ENTRY DAO
// ============================================================
@Dao
interface EntryDao {

    // Live streams for reactive UI. Room emits on every write
    // that affects the queried rows.

    @Query("SELECT * FROM entries WHERE deleted = 0 ORDER BY updated_at DESC")
    fun observeAll(): Flow<List<EntryEntity>>

    @Query("SELECT * FROM entries WHERE kind = :kind AND deleted = 0 ORDER BY updated_at DESC")
    fun observeByKind(kind: String): Flow<List<EntryEntity>>

    /** Technique sections also filter by cat. */
    @Query("""
        SELECT * FROM entries
        WHERE kind = 'technique' AND cat = :cat AND deleted = 0
        ORDER BY updated_at DESC
    """)
    fun observeTechniquesByCat(cat: String): Flow<List<EntryEntity>>

    /** Bars sections filter by bar count. */
    @Query("""
        SELECT * FROM entries
        WHERE kind = 'bars' AND bars = :barCount AND deleted = 0
        ORDER BY updated_at DESC
    """)
    fun observeBarsByCount(barCount: Int): Flow<List<EntryEntity>>

    @Query("SELECT * FROM entries WHERE id = :id LIMIT 1")
    fun observeById(id: String): Flow<EntryEntity?>

    @Query("SELECT * FROM entries WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): EntryEntity?

    @Query("SELECT * FROM entries WHERE deleted = 1 ORDER BY updated_at DESC")
    fun observeTrashed(): Flow<List<EntryEntity>>

    /** Full-text search across name, notes, description, tags, extraJson. */
    @Query("""
        SELECT * FROM entries
        WHERE deleted = 0 AND (
            name        LIKE '%' || :query || '%' OR
            notes       LIKE '%' || :query || '%' OR
            description LIKE '%' || :query || '%' OR
            tags        LIKE '%' || :query || '%' OR
            extra_json  LIKE '%' || :query || '%'
        )
        ORDER BY updated_at DESC
        LIMIT 60
    """)
    suspend fun search(query: String): List<EntryEntity>

    @Query("SELECT * FROM entries WHERE deleted=0 AND (name LIKE '%' || :q || '%' OR notes LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%' OR tags LIKE '%' || :q || '%') ORDER BY updated_at DESC LIMIT 100")
    fun searchFlow(q: String): Flow<List<EntryEntity>>

    @Upsert
    suspend fun upsert(entry: EntryEntity)

    @Upsert
    suspend fun upsertAll(entries: List<EntryEntity>)

    /** Soft delete — moves to trash. */
    @Query("UPDATE entries SET deleted = 1, updated_at = :now WHERE id = :id")
    suspend fun softDelete(id: String, now: Long = System.currentTimeMillis())

    /** Restore from trash. */
    @Query("UPDATE entries SET deleted = 0, updated_at = :now WHERE id = :id")
    suspend fun restore(id: String, now: Long = System.currentTimeMillis())

    /** Hard delete — used for purging trashed items. */
    @Query("DELETE FROM entries WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Query("DELETE FROM entries WHERE deleted = 1")
    suspend fun purgeAllTrashed()

    /** Count by kind (for section headers and stats). */
    @Query("""
        SELECT kind, COUNT(*) as count FROM entries
        WHERE deleted = 0
        GROUP BY kind
    """)
    fun observeKindCounts(): Flow<List<KindCount>>

    @Query("SELECT COUNT(*) FROM entries WHERE deleted = 0")
    suspend fun totalCount(): Int

    @Query("SELECT COUNT(*) FROM entries WHERE deleted=0 AND created_at >= :since")
    suspend fun countCreatedSince(since: Long): Int

    @Query("SELECT cat, COUNT(*) as cnt FROM entries WHERE deleted=0 AND kind='technique' AND cat IS NOT NULL GROUP BY cat")
    suspend fun techniqueCatCounts(): List<CatCount>

    @Query("SELECT COUNT(*) FROM entries WHERE deleted=0 AND kind=:kind")
    suspend fun countByKind(kind: String): Int

    @Query("SELECT COUNT(*) FROM entries WHERE deleted=0 AND kind=:kind AND created_at >= :since")
    suspend fun countByKindCreatedSince(kind: String, since: Long): Int
}

/** Lightweight projection used for stat tiles. */
data class KindCount(val kind: String, val count: Int)
data class CatCount(val cat: String, @ColumnInfo(name = "cnt") val cnt: Int)

// ============================================================
// FILE META DAO
// ============================================================
@Dao
interface FileMetaDao {

    @Query("SELECT * FROM file_meta WHERE entry_id = :entryId AND deleted = 0 ORDER BY created_at DESC")
    fun observeByEntry(entryId: String): Flow<List<FileMetaEntity>>

    @Query("SELECT * FROM file_meta WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): FileMetaEntity?

    @Query("SELECT * FROM file_meta WHERE deleted = 0 ORDER BY created_at DESC")
    suspend fun getAll(): List<FileMetaEntity>

    @Query("SELECT COUNT(*) FROM file_meta WHERE entry_id = :entryId AND deleted = 0")
    fun observeCountForEntry(entryId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM file_meta WHERE deleted = 0")
    fun observeTotalCount(): Flow<Int>

    @Upsert
    suspend fun upsert(meta: FileMetaEntity)

    @Query("UPDATE file_meta SET deleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("DELETE FROM file_meta WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Query("UPDATE file_meta SET description = :desc WHERE id = :id")
    suspend fun updateDescription(id: String, desc: String)

    @Query("SELECT COUNT(*) FROM file_meta WHERE deleted = 0")
    suspend fun totalCount(): Int

    /** Total storage used by non-deleted files. */
    @Query("SELECT COALESCE(SUM(size), 0) FROM file_meta WHERE deleted = 0")
    fun observeTotalSize(): Flow<Long>
}

// ============================================================
// PRACTICE LOG DAO
// ============================================================
@Dao
interface PracticeLogDao {

    @Query("SELECT * FROM practice_log ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int = 100): Flow<List<PracticeLogEntity>>

    @Query("SELECT * FROM practice_log WHERE day >= :fromDay ORDER BY timestamp DESC")
    suspend fun getSince(fromDay: String): List<PracticeLogEntity>

    @Query("""
        SELECT day, SUM(minutes) as total
        FROM practice_log
        WHERE day >= :fromDay
        GROUP BY day
    """)
    suspend fun dailyMinutesSince(fromDay: String): List<DayMinutes>

    @Query("SELECT SUM(minutes) FROM practice_log")
    suspend fun totalMinutes(): Int

    @Query("SELECT COUNT(*) FROM practice_log WHERE type = 'practice'")
    suspend fun sessionCount(): Int

    @Query("SELECT DISTINCT day FROM practice_log ORDER BY day DESC")
    suspend fun allPracticeDays(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: PracticeLogEntity): Long
}

data class DayMinutes(val day: String, val total: Int)

// ============================================================
// HEALTH LOG DAO
// ============================================================
@Dao
interface HealthLogDao {

    @Query("SELECT * FROM health_log ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int = 20): Flow<List<HealthLogEntity>>

    @Query("SELECT * FROM health_log ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<HealthLogEntity>

    @Insert
    suspend fun insert(log: HealthLogEntity): Long
}

// ============================================================
// GAME STATE DAO
// ============================================================
@Dao
interface GameStateDao {

    @Query("SELECT * FROM game_state WHERE id = 1 LIMIT 1")
    fun observe(): Flow<GameStateEntity?>

    @Query("SELECT * FROM game_state WHERE id = 1 LIMIT 1")
    suspend fun get(): GameStateEntity?

    @Upsert
    suspend fun upsert(state: GameStateEntity)
}

// ============================================================
// KV STORE DAO
// ============================================================
@Dao
interface KvDao {

    @Query("SELECT value FROM kv_store WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): String?

    @Query("SELECT * FROM kv_store")
    suspend fun getAll(): List<KvEntity>

    @Upsert
    suspend fun put(entry: KvEntity)

    @Query("DELETE FROM kv_store WHERE `key` = :key")
    suspend fun delete(key: String)
}
