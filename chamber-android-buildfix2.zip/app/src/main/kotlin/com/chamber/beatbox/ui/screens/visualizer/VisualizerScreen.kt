package com.chamber.beatbox.ui.screens.visualizer

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.data.audio.VisualizerEngine
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.theme.*
import kotlin.math.*

private data class Particle(var x: Float, var y: Float, var vx: Float = 0f, var vy: Float = 0f, var life: Float)

@Composable
fun VisualizerScreen(nav: NavHostController, vm: VisualizerViewModel = hiltViewModel()) {
    val mode by vm.mode.collectAsStateWithLifecycle()
    val frame by vm.latestFrame.collectAsStateWithLifecycle()
    val isRunning by vm.isRunning.collectAsStateWithLifecycle()
    val particles = remember {
        MutableList(180) { Particle((0..1000).random()/1000f, (0..1000).random()/1000f,
            life = (0..1000).random()/1000f) }
    }

    Column(Modifier.fillMaxSize().background(BgDark)) {
        SectionHead("◉","Visualizer","LIVE MIC · ${mode.label}",
            Modifier.padding(horizontal = 14.dp, vertical = 16.dp))

        Canvas(Modifier.fillMaxWidth().aspectRatio(1f).border(3.dp, InkOnDark).background(BgDark)) {
            val f = frame
            if (f != null) drawVizMode(mode, f, particles) else drawIdleGrid()
        }

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            VisualizerEngine.Mode.values().forEach { m ->
                val active = m == mode
                Box(Modifier.border(2.dp, InkOnDark).background(if (active) InkOnDark else BgDark)
                    .clickable { vm.setMode(m) }.padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Text(m.label, style = ChamberType.ButtonSm, color = if (active) BgDark else InkOnDark)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        ChamberButton(if (isRunning) "■ STOP" else "▶ START",
            onClick = { if (isRunning) vm.stop() else vm.start() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp))
        Spacer(Modifier.height(ChamberDimens.BottomPadding))
    }
}

private fun DrawScope.drawVizMode(mode: VisualizerEngine.Mode, f: VisualizerEngine.VisualizerFrame, particles: MutableList<Particle>) = when (mode) {
    VisualizerEngine.Mode.SPECTRUM   -> drawSpectrum(f)
    VisualizerEngine.Mode.PARTICLES  -> drawParticles(f, particles)
    VisualizerEngine.Mode.WAVE       -> drawWave(f)
    VisualizerEngine.Mode.RINGS      -> drawRings(f)
    VisualizerEngine.Mode.CHLADNI    -> drawChladni(f)
    VisualizerEngine.Mode.GRID_BURST -> drawGridBurst(f)
}

private fun DrawScope.drawSpectrum(f: VisualizerEngine.VisualizerFrame) {
    val bw = size.width / f.bands.size
    f.bands.forEachIndexed { i, amp ->
        val bh = amp * size.height * 0.95f
        if (bh > 0.5f) drawRect(Color.White, Offset(i*bw+1f, size.height-bh), Size((bw-2f).coerceAtLeast(1f), bh))
    }
}

private fun DrawScope.drawWave(f: VisualizerEngine.VisualizerFrame) {
    val wave = f.wave; if (wave.isEmpty()) return
    val mid = size.height/2f
    val path = Path().apply {
        moveTo(0f, mid - wave[0]*mid*0.85f)
        wave.forEachIndexed { i, v -> lineTo(i.toFloat()/wave.size*size.width, mid - v*mid*0.85f) }
    }
    drawPath(path, Color.White, style = Stroke(2.dp.toPx()))
    drawLine(Color.White.copy(alpha=0.15f), Offset(0f,mid), Offset(size.width,mid), 1.dp.toPx())
}

private fun DrawScope.drawParticles(f: VisualizerEngine.VisualizerFrame, particles: MutableList<Particle>) {
    val W = size.width; val H = size.height; val energy = f.energy; val bands = f.bands
    particles.forEachIndexed { i, p ->
        val bi = (i * VisualizerEngine.BAND_COUNT / particles.size).coerceIn(0, VisualizerEngine.BAND_COUNT-1)
        val force = bands[bi] * energy * 0.04f
        p.vx = p.vx*0.9f + (Math.random().toFloat()-0.5f)*force
        p.vy = p.vy*0.9f + (Math.random().toFloat()-0.5f)*force
        p.x = ((p.x+p.vx) + 1f) % 1f; p.y = ((p.y+p.vy) + 1f) % 1f
        p.life = (p.life + energy*0.01f) % 1f
        val sz = (2.dp + p.life*4.dp).toPx()
        drawRect(Color.White.copy(alpha=(0.2f+p.life*0.8f).coerceIn(0f,1f)),
            Offset(p.x*W - sz/2, p.y*H - sz/2), Size(sz, sz))
    }
}

private fun DrawScope.drawRings(f: VisualizerEngine.VisualizerFrame) {
    val cx = size.width/2f; val cy = size.height/2f; val maxR = minOf(cx,cy)*0.92f
    val nRings = 6; val bands = f.bands
    for (r in 0 until nRings) {
        val base = (r+1f)/nRings * maxR
        val s = r * (VisualizerEngine.BAND_COUNT/nRings); val e = (s + VisualizerEngine.BAND_COUNT/nRings).coerceAtMost(VisualizerEngine.BAND_COUNT)
        val avg = bands.slice(s until e).average().toFloat()
        drawCircle(Color.White.copy(alpha=(0.3f+avg*0.7f).coerceIn(0f,1f)),
            base*(0.7f+avg*0.3f), Offset(cx,cy), style=Stroke((1f+avg*3f).dp.toPx()))
    }
    drawCircle(Color.White, 4.dp.toPx(), Offset(cx,cy))
}

private fun DrawScope.drawChladni(f: VisualizerEngine.VisualizerFrame) {
    val m = (f.peakBin % 5 + 1).toFloat(); val n = (f.peakBin/5 % 5 + 1).toFloat()
    val res = 48; val dotR = 3.dp.toPx(); val energy = f.energy.coerceAtLeast(0.01f)
    for (row in 0..res) for (col in 0..res) {
        val nx = col.toFloat()/res; val ny = row.toFloat()/res
        val z = sin(m * PI.toFloat() * nx) * sin(n * PI.toFloat() * ny)
        val threshold = 0.12f + (1f-energy)*0.2f
        if (abs(z) < threshold)
            drawCircle(Color.White.copy(alpha=((1f-abs(z)/threshold)*energy).coerceIn(0f,1f)),
                dotR, Offset(nx*size.width, ny*size.height))
    }
}

private fun DrawScope.drawGridBurst(f: VisualizerEngine.VisualizerFrame) {
    val cols = 8; val rows = 8; val cw = size.width/cols; val ch = size.height/rows; val bands = f.bands
    for (r in 0 until rows) for (c in 0 until cols) {
        val bi = ((r*cols+c)*VisualizerEngine.BAND_COUNT/(rows*cols)).coerceIn(0, VisualizerEngine.BAND_COUNT-1)
        val amp = bands[bi]; val cx2 = c*cw+cw/2f; val cy2 = r*ch+ch/2f; val sz = cw*0.45f*amp
        drawRect(Color.White.copy(alpha=0.07f), Offset(c*cw+2f,r*ch+2f), Size(cw-4f,ch-4f), style=Stroke(1.dp.toPx()))
        if (sz > 0.5f) drawRect(Color.White.copy(alpha=(0.4f+amp*0.6f).coerceIn(0f,1f)), Offset(cx2-sz/2,cy2-sz/2), Size(sz,sz))
    }
}

private fun DrawScope.drawIdleGrid() {
    val cols = 8; val rows = 8; val cw = size.width/cols; val ch = size.height/rows
    for (r in 0 until rows) for (c in 0 until cols)
        drawRect(Color.White.copy(alpha=0.06f), Offset(c*cw+2f,r*ch+2f), Size(cw-4f,ch-4f), style=Stroke(1.dp.toPx()))
}
