package com.chamber.beatbox.ui.screens.godmode

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.chamber.beatbox.ui.components.*
import com.chamber.beatbox.ui.navigation.Routes
import com.chamber.beatbox.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.sqrt

@Composable
fun GodmodeScreen(nav: NavHostController, vm: GodmodeViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsStateWithLifecycle()
    val c = LocalChamberColors.current
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var showInsights by remember { mutableStateOf(true) }

    // Physics tick
    LaunchedEffect(canvasSize, state.nodeCount) {
        if (canvasSize.width == 0) return@LaunchedEffect
        // warm-up settle
        repeat(40) {
            vm.stepPhysics(canvasSize.width.toFloat(), canvasSize.height.toFloat())
        }
        while (true) {
            vm.stepPhysics(canvasSize.width.toFloat(), canvasSize.height.toFloat())
            delay(32)
        }
    }

    Column(Modifier.fillMaxSize().background(c.bg)) {
        SectionHead(
            "G", "GODMODE", "MAP OF EVERYTHING · COACH",
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
        )

        // Toolbar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${state.nodeCount} NODES · ${state.edgeCount} LINKS · ${state.orphanCount} ORPHANS",
                style = ChamberType.MonoLabel,
                color = c.muted,
                modifier = Modifier.weight(1f)
            )
            ChamberButton(
                if (showInsights) "GRAPH" else "COACH",
                onClick = { showInsights = !showInsights },
                size = ButtonSize.Small
            )
            ChamberButton(
                "RESEED",
                onClick = {
                    vm.reseedLayout(canvasSize.width.toFloat(), canvasSize.height.toFloat())
                },
                size = ButtonSize.Small
            )
        }

        Spacer(Modifier.height(8.dp))

        if (showInsights) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(14.dp)
            ) {
                item {
                    HintBox("Force-directed map of every entry and cross-link. Switch to GRAPH to explore; tap nodes to open.")
                    Spacer(Modifier.height(12.dp))
                    SectionLine("Coach")
                    Spacer(Modifier.height(8.dp))
                }
                items(state.insights) { ins ->
                    Column(
                        Modifier.fillMaxWidth().border(2.dp, c.ink).padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(ins.glyph, style = ChamberType.Brand, color = c.ink, modifier = Modifier.width(40.dp))
                            Text(ins.title, style = ChamberType.BodyBold, color = c.ink)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(ins.body, style = ChamberType.Mono, color = c.muted)
                    }
                    Spacer(Modifier.height(4.dp))
                }
                item {
                    Spacer(Modifier.height(12.dp))
                    ChamberButton(
                        "OPEN GRAPH VIEW",
                        onClick = { showInsights = false },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(ChamberDimens.BottomPadding))
                }
            }
        } else {
            // Graph canvas
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .border(3.dp, c.ink)
                    .onSizeChanged { canvasSize = it }
            ) {
                val nodes = state.nodes
                val edges = state.edges
                val selected = state.selectedId
                val byId = remember(nodes) { nodes.associateBy { it.id } }

                Canvas(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(nodes) {
                            detectTapGestures { pos ->
                                val hit = nodes.minByOrNull { n ->
                                    val dx = n.x - pos.x
                                    val dy = n.y - pos.y
                                    dx * dx + dy * dy
                                }
                                if (hit != null) {
                                    val dx = hit.x - pos.x
                                    val dy = hit.y - pos.y
                                    if (sqrt(dx * dx + dy * dy) < 36f) {
                                        vm.select(hit.id)
                                    } else {
                                        vm.select(null)
                                    }
                                }
                            }
                        }
                ) {
                    // edges
                    for (e in edges) {
                        val a = byId[e.from] ?: continue
                        val b = byId[e.to] ?: continue
                        val active = selected == a.id || selected == b.id
                        drawLine(
                            color = if (active) Color(0xFFCC0000) else Color.White.copy(alpha = 0.35f),
                            start = Offset(a.x, a.y),
                            end = Offset(b.x, b.y),
                            strokeWidth = if (active) 3f else 1.5f
                        )
                    }
                    // nodes
                    for (n in nodes) {
                        val isSel = n.id == selected
                        val r = when {
                            isSel -> 16f
                            n.pin -> 12f
                            else -> 9f
                        }
                        drawCircle(
                            color = if (isSel) Color(0xFFCC0000) else Color.White,
                            radius = r,
                            center = Offset(n.x, n.y)
                        )
                        if (!isSel) {
                            drawCircle(
                                color = Color.Black,
                                radius = r - 2.5f,
                                center = Offset(n.x, n.y)
                            )
                        }
                    }
                }

                // Selected label overlay
                val selNode = nodes.find { it.id == selected }
                if (selNode != null) {
                    Column(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(c.bg)
                            .border(2.dp, c.ink)
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(glyph(selNode.kind), style = ChamberType.Brand, color = c.ink, modifier = Modifier.width(36.dp))
                            Column(Modifier.weight(1f)) {
                                Text(selNode.name, style = ChamberType.BodyBold, color = c.ink)
                                Text(
                                    selNode.kind.uppercase() + (selNode.bpm?.let { " · $it BPM" } ?: ""),
                                    style = ChamberType.MonoLabel,
                                    color = c.muted
                                )
                            }
                            ChamberButton(
                                "OPEN",
                                onClick = { nav.navigate(Routes.entry(selNode.id)) },
                                size = ButtonSize.Small
                            )
                        }
                    }
                }

                if (nodes.isEmpty()) {
                    Text(
                        "NO ENTRIES YET",
                        style = ChamberType.MonoLabel,
                        color = c.muted,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }
}

private fun glyph(kind: String) = when (kind) {
    "champ" -> "+"; "idea" -> "!"; "bars" -> "▤"; "oneshot" -> "1"; "genre" -> "♫"
    "social" -> "@"; "vocode" -> "≈"; "goal" -> "◎"; "session" -> "▸"
    "pattern" -> "▦"; "setlist" -> "≡"; "technique" -> "TEC"; else -> "·"
}
