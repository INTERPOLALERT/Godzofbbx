package com.chamber.beatbox

import android.app.Application
import com.chamber.beatbox.data.repository.EntryRepository
import com.chamber.beatbox.data.repository.SettingsRepository
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

@HiltAndroidApp
class ChamberApp : Application() {

    @Inject lateinit var repo: EntryRepository
    @Inject lateinit var settings: SettingsRepository

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Exact GENRES list from HTML chamber-1-4-1
    private val SEED_GENRES = listOf(
        "Hip-Hop","House","Techno","Drum & Bass","Liquid D&B","Neurofunk","Jungle","Garage","UK Garage",
        "Grime","Dubstep","Trap","Pop","R&B","Reggae","Dancehall","Trance","Breakbeat","Funk","Soul","Jazz","Rock",
        "Metal","Drumstep","Dub","Afrobeat","Amapiano","Latin","Reggaeton","Experimental","Ambient"
    )

    override fun onCreate() {
        super.onCreate()
        scope.launch { seedGenresIfNeeded() }
    }

    private suspend fun seedGenresIfNeeded() {
        val alreadySeeded = settings.genresSeeded.first()
        if (alreadySeeded) return

        SEED_GENRES.forEach { name ->
            val entry = repo.newEntry(kind = "genre", name = name)
            repo.upsert(entry)
        }
        settings.setGenresSeeded(true)
    }
}
