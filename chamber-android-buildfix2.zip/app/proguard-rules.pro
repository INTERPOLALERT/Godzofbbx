# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers @androidx.room.Entity class * { *; }

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *; }
-keep,includedescriptorclasses class com.chamber.beatbox.**$$serializer { *; }
-keepclassmembers class com.chamber.beatbox.** {
    *** Companion;
}
-keepclasseswithmembers class com.chamber.beatbox.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Hilt
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# Navigation Compose
-keepnames class androidx.navigation.** { *; }

# DataStore
-keep class androidx.datastore.** { *; }

# Keep all data classes used as Room entities / serialized models
-keepclassmembers class com.chamber.beatbox.data.db.entities.** { *; }
-keepclassmembers class com.chamber.beatbox.data.repository.** { *; }
