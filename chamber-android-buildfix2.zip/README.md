# CHAMBER — Native Android

Pure Kotlin + Jetpack Compose port of the CHAMBER beatbox training OS (no WebView).

## Open in Android Studio

1. Unzip this folder
2. Android Studio → Open → select the `chamber` directory (the one containing `settings.gradle.kts`)
3. Let Gradle sync (first time may download Gradle 8.9 + SDK packages)
4. If prompted for SDK, install Android SDK 34+ and build-tools
5. Connect a phone (USB debugging) or start an emulator
6. Run ▶️

## If Gradle wrapper fails

```
cd chamber
gradle wrapper --gradle-version=8.9
```

## Package

- `applicationId`: check `app/build.gradle.kts`
- Min SDK: see `app/build.gradle.kts`
- Permissions: RECORD_AUDIO, storage (legacy)

## Feature map

Home, sections, entry editor, pattern lab, trainer (drill/speed/gap/timer/warm/cool/battle),
quests + badges, stats, visualizer, GODMODE graph, search commands, data import/export,
metronome (full panel + gap + ramp), audio trim, quick capture.
